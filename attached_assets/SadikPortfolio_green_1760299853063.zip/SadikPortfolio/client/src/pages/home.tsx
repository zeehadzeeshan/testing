import { useEffect } from "react";
import IntroAnimation from "@/components/intro-animation";
import ParticlesBackground from "@/components/particles-background";
import Navbar from "@/components/navbar";
import HeroSection from "@/components/hero-section";
import AboutSection from "@/components/about-section";
import SkillsSection from "@/components/skills-section";
import AchievementsSection from "@/components/achievements-section";
import ProjectsSection from "@/components/projects-section";
import WriteupsSection from "@/components/writeups-section";
import ContactSection from "@/components/contact-section";

export default function Home() {
  useEffect(() => {
    // Smooth scroll behavior for anchor links
    const handleAnchorClick = (e: Event) => {
      const target = e.target as HTMLAnchorElement;
      if (target.href && target.href.includes('#')) {
        e.preventDefault();
        const id = target.href.split('#')[1];
        const element = document.getElementById(id);
        if (element) {
          element.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });
        }
      }
    };

    document.addEventListener('click', handleAnchorClick);
    return () => document.removeEventListener('click', handleAnchorClick);
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground" data-testid="home-page">
      <IntroAnimation />
      <ParticlesBackground />
      <Navbar />
      
      <main>
        <HeroSection />
        <AboutSection />
        <SkillsSection />
        <AchievementsSection />
        
        {/* Certifications Section */}
        <section id="certifications" className="py-20 bg-muted/50">
          <div className="container mx-auto px-6">
            <h2 className="text-4xl md:text-5xl font-display font-bold text-center mb-16 gradient-text">
              Certifications
            </h2>
            
            <div className="max-w-3xl mx-auto text-center">
              <div className="bg-card p-12 rounded-xl border border-border">
                <i className="fas fa-certificate text-6xl text-primary mb-6"></i>
                <h3 className="text-2xl font-bold text-card-foreground mb-4">
                  Certifications Coming Soon...
                </h3>
                <p className="text-muted-foreground">
                  Certifications Section Under Development — Updates Coming Soon.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        <ProjectsSection />
        <WriteupsSection />
        <ContactSection />
      </main>

      {/* Footer */}
      <footer className="bg-muted border-t border-border py-8">
        <div className="container mx-auto px-6 text-center">
          <p className="text-muted-foreground">
            &copy; 2024 <span className="text-primary">Sadik Mahmud</span>. All rights reserved.
          </p>
          <p className="text-muted-foreground text-sm mt-2">
            Crafted with <i className="fas fa-heart text-red-500"></i> by @sadik0x01
          </p>
        </div>
      </footer>
    </div>
  );
}
