import { Link } from "wouter";
import ParticlesBackground from "@/components/particles-background";
import { Card, CardContent } from "@/components/ui/card";

export default function ReconMethodology() {
  return (
    <div data-testid="recon-methodology-page">
      <ParticlesBackground />
      
      {/* Back Button */}
      <div className="fixed top-20 left-6 z-40">
        <Link 
          href="/"
          className="inline-flex items-center gap-2 bg-card hover:bg-muted px-4 py-2 rounded-lg border border-border transition-colors"
          data-testid="back-button"
        >
          <i className="fas fa-arrow-left"></i>
          <span>Back to Home</span>
        </Link>
      </div>

      <div className="min-h-screen bg-background pt-20">
        <div className="container mx-auto px-6 py-8">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-display font-bold gradient-text mb-4">
              Recon Methodology
            </h1>
            <p className="text-muted-foreground text-lg">
              Comprehensive reconnaissance techniques and methodologies
            </p>
          </div>

          {/* Coming Soon Message */}
          <div className="max-w-3xl mx-auto">
            <Card className="hover-lift">
              <CardContent className="p-12 text-center">
                <i className="fas fa-search text-6xl text-primary mb-6"></i>
                <h3 className="text-2xl font-bold text-card-foreground mb-4">
                  Coming Soon
                </h3>
                <p className="text-muted-foreground text-lg mb-6">
                  Comprehensive reconnaissance methodology content is under development. 
                  This section will include detailed guides, tools, and techniques for 
                  security research and bug bounty hunting.
                </p>
                <div className="text-muted-foreground">
                  <p className="mb-2">Expected content:</p>
                  <ul className="text-left inline-block space-y-1">
                    <li>• Subdomain enumeration techniques</li>
                    <li>• Port scanning methodologies</li>
                    <li>• Technology identification</li>
                    <li>• Vulnerability assessment workflows</li>
                    <li>• OSINT gathering methods</li>
                    <li>• Automation tools and scripts</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
