import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import DorkSearchInterface from "@/components/dork-search-interface";
import ParticlesBackground from "@/components/particles-background";
import { Skeleton } from "@/components/ui/skeleton";
import type { Dork } from "@shared/schema";

export default function BugbountyDorks() {
  const { data: dorks = [], isLoading, error } = useQuery<Dork[]>({
    queryKey: ['/api/dorks/bugbounty'],
  });

  if (error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center" data-testid="error-state">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-destructive mb-4">Error Loading Bug Bounty Dorks</h1>
          <p className="text-muted-foreground mb-4">Failed to load Bug Bounty dorks. Please try again later.</p>
          <Link href="/" className="text-primary hover:text-accent underline">
            Go Back Home
          </Link>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background pt-20" data-testid="loading-state">
        <ParticlesBackground />
        <div className="container mx-auto px-6 py-8">
          <div className="text-center mb-12">
            <Skeleton className="h-12 w-96 mx-auto mb-4" />
            <Skeleton className="h-6 w-64 mx-auto" />
          </div>
          <div className="max-w-4xl mx-auto space-y-4">
            {[...Array(10)].map((_, i) => (
              <Skeleton key={i} className="h-24 w-full" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div data-testid="bugbounty-dorks-page">
      <ParticlesBackground />
      
      {/* Back Button */}
      <div className="fixed top-20 left-6 z-40">
        <Link 
          href="/"
          className="inline-flex items-center gap-2 bg-card hover:bg-muted px-4 py-2 rounded-lg border border-border transition-colors"
          data-testid="back-button"
        >
          <i className="fas fa-arrow-left"></i>
          <span>Back to Home</span>
        </Link>
      </div>

      <DorkSearchInterface
        dorks={dorks}
        type="bugbounty"
        title="Bug Bounty Dorks"
        searchPlaceholder="Search Bug Bounty dorks..."
      />
    </div>
  );
}
