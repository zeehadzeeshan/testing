import { useEffect, useRef, useState } from "react";

interface Skill {
  name: string;
  percentage: number;
}

const skills: Skill[] = [
  { name: "Web Application Pentesting", percentage: 90 },
  { name: "API Pentesting", percentage: 80 },
  { name: "Bash", percentage: 40 },
  { name: "Mobile Pentesting", percentage: 75 },
  { name: "Smart Contract Hacking", percentage: 25 },
  { name: "Javascript", percentage: 85 }
];

export default function SkillsSection() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.5 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section id="skills" className="py-20 bg-muted/50" ref={sectionRef} data-testid="skills-section">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-display font-bold text-center mb-16 gradient-text">
          Technical Skills
        </h2>
        
        <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8">
          {skills.map((skill, index) => (
            <div key={skill.name} className="skill-item" data-testid={`skill-${index}`}>
              <div className="flex justify-between mb-2">
                <span className="text-foreground font-medium">{skill.name}</span>
                <span className="text-primary font-bold">{skill.percentage}%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                <div 
                  className={`progress-bar h-full bg-gradient-to-r from-primary to-accent rounded-full transition-all duration-1500 ${
                    isVisible ? 'animate' : ''
                  }`}
                  style={{
                    '--progress-width': `${skill.percentage}%`,
                    width: isVisible ? `${skill.percentage}%` : '0%'
                  } as React.CSSProperties}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
