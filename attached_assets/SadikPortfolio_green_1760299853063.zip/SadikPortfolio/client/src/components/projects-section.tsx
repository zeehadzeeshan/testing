import { Link } from "wouter";

export default function ProjectsSection() {
  const projects = [
    {
      title: "GitHub Dorks",
      description: "Advanced GitHub search queries for security research",
      icon: "fab fa-github",
      color: "text-primary",
      path: "/github-dorks"
    },
    {
      title: "Shodan Dorks",
      description: "IoT and device discovery search queries",
      icon: "fas fa-satellite-dish",
      color: "text-secondary",
      path: "/shodan-dorks"
    },
    {
      title: "Google Dorks",
      description: "Google hacking database for pentesting",
      icon: "fab fa-google",
      color: "text-primary",
      path: "/google-dorks"
    },
    {
      title: "Bug Bounty Dorks",
      description: "Find unique bug bounty platforms and programs",
      icon: "fas fa-bug",
      color: "text-secondary",
      path: "/bugbounty-dorks"
    },
    {
      title: "Recon Methodology",
      description: "Comprehensive reconnaissance techniques",
      icon: "fas fa-search",
      color: "text-primary",
      path: "/recon-methodology"
    }
  ];

  return (
    <section id="projects" className="py-20" data-testid="projects-section">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-display font-bold text-center mb-16 gradient-text">
          My Projects
        </h2>
        
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <Link 
              key={index}
              href={project.path}
              className="project-card bg-card p-6 rounded-xl border border-border hover-lift block group"
              data-testid={`project-${index}`}
            >
              <div className="flex items-center justify-between mb-4">
                <i className={`${project.icon} text-4xl ${project.color} group-hover:scale-110 transition-transform`}></i>
                <i className="fas fa-arrow-right text-2xl text-muted-foreground group-hover:text-primary transition-colors"></i>
              </div>
              <h3 className="text-xl font-bold text-card-foreground mb-2">{project.title}</h3>
              <p className="text-muted-foreground text-sm">{project.description}</p>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
