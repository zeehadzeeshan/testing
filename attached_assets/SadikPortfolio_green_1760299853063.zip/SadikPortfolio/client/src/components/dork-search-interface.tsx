import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import type { Dork } from "@shared/schema";

interface DorkSearchInterfaceProps {
  dorks: Dork[];
  type: string;
  title: string;
  searchPlaceholder?: string;
  categories?: string[];
}

export default function DorkSearchInterface({ 
  dorks, 
  type, 
  title, 
  searchPlaceholder = "Search dorks...",
  categories = []
}: DorkSearchInterfaceProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredDorks, setFilteredDorks] = useState<Dork[]>(dorks);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  useEffect(() => {
    let filtered = dorks;

    // Filter by search term
    if (searchTerm.trim()) {
      filtered = filtered.filter(dork =>
        dork.query.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (dork.description && dork.description.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    // Filter by category
    if (selectedCategory !== "all") {
      filtered = filtered.filter(dork => dork.category === selectedCategory);
    }

    setFilteredDorks(filtered);
  }, [dorks, searchTerm, selectedCategory]);

  const handleGoogleSearch = (query: string) => {
    const encodedQuery = encodeURIComponent(query);
    window.open(`https://google.com/search?q=${encodedQuery}`, '_blank');
  };

  const handleShodanSearch = (query: string) => {
    const encodedQuery = encodeURIComponent(query);
    window.open(`https://shodan.io/search?query=${encodedQuery}`, '_blank');
  };

  const handleGithubSearch = (query: string) => {
    const encodedQuery = encodeURIComponent(query);
    window.open(`https://github.com/search?q=${encodedQuery}`, '_blank');
  };

  const getSearchUrl = (query: string) => {
    switch (type) {
      case 'github':
        return () => handleGithubSearch(query);
      case 'shodan':
        return () => handleShodanSearch(query);
      case 'google':
      case 'bugbounty':
      default:
        return () => handleGoogleSearch(query);
    }
  };

  return (
    <div className="min-h-screen bg-background pt-20" data-testid={`${type}-search-interface`}>
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-display font-bold gradient-text mb-4">
            {title}
          </h1>
          <p className="text-muted-foreground text-lg">
            Advanced {type} search queries for security research
          </p>
        </div>

        {/* Search Interface */}
        <div className="max-w-4xl mx-auto mb-8">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <Input
                type="text"
                placeholder={searchPlaceholder}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
                data-testid="search-input"
              />
            </div>
            {categories.length > 0 && (
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 rounded-lg border border-border bg-background text-foreground"
                data-testid="category-filter"
              >
                <option value="all">All Categories</option>
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Results Count */}
          <div className="flex justify-between items-center mb-6">
            <p className="text-muted-foreground" data-testid="results-count">
              Found {filteredDorks.length} {type} dorks
            </p>
          </div>

          {/* Dork Results */}
          <div className="grid gap-4">
            {filteredDorks.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <p className="text-muted-foreground text-lg">No dorks found matching your search.</p>
                </CardContent>
              </Card>
            ) : (
              filteredDorks.map((dork, index) => (
                <Card key={dork.id} className="hover-lift" data-testid={`dork-${index}`}>
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex-1">
                        <code className="bg-muted px-3 py-2 rounded text-sm font-mono text-foreground block break-all">
                          {dork.query}
                        </code>
                        {dork.description && (
                          <p className="text-muted-foreground text-sm mt-2">{dork.description}</p>
                        )}
                      </div>
                      <div className="flex gap-2 flex-shrink-0">
                        <Button
                          onClick={getSearchUrl(dork.query)}
                          className="bg-primary hover:bg-accent text-primary-foreground"
                          size="sm"
                          data-testid={`search-${index}`}
                        >
                          <i className={`fas ${type === 'github' ? 'fa-code-branch' : type === 'shodan' ? 'fa-satellite-dish' : 'fa-search'} mr-2`}></i>
                          Search in {type === 'github' ? 'GitHub' : type === 'shodan' ? 'Shodan' : 'Google'}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
