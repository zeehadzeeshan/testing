import { useEffect, useState } from "react";

export default function IntroAnimation() {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
    }, 4000);

    return () => clearTimeout(timer);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="intro-container" data-testid="intro-animation">
      <div className="text-center">
        <div className="animate-logo-float">
          <i className="fas fa-spider spider-icon" data-testid="spider-icon"></i>
        </div>
        <div className="animate-fade-in mt-8">
          <h1 className="text-3xl md:text-5xl font-display font-bold text-primary mb-4">
            SADIK0x01
          </h1>
          <div className="text-muted-foreground">
            Crafted with <i className="fas fa-heart text-red-500"></i> by{" "}
            <a 
              href="https://github.com/sadik0x01" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-primary hover:text-accent transition-colors px-3 py-1 bg-primary/10 rounded"
              data-testid="credit-link"
            >
              @sadik0x01
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
