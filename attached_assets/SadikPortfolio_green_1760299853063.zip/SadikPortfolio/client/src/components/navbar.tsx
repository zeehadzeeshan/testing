import { useState, useEffect } from "react";
import { useTheme } from "@/components/theme-provider";

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleMobileMenuClose = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <nav 
        className={`fixed top-0 w-full bg-background/95 backdrop-blur-md border-b border-border z-50 transition-all duration-300 ${
          isScrolled ? 'shadow-lg shadow-primary/10' : ''
        }`}
        data-testid="navbar"
      >
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <a 
            href="#home" 
            className="text-2xl font-display font-bold text-primary flex items-center gap-2"
            data-testid="logo-link"
          >
            <i className="fas fa-bug"></i>
            <span className="hidden sm:inline">SADIK0x01</span>
          </a>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#home" className="hover:text-primary transition-colors" data-testid="nav-home">Home</a>
            <a href="#about" className="hover:text-primary transition-colors" data-testid="nav-about">About</a>
            <a href="#skills" className="hover:text-primary transition-colors" data-testid="nav-skills">Skills</a>
            <a href="#achievements" className="hover:text-primary transition-colors" data-testid="nav-achievements">Achievements</a>
            <a href="#projects" className="hover:text-primary transition-colors" data-testid="nav-projects">Projects</a>
            <a href="#writeups" className="hover:text-primary transition-colors" data-testid="nav-writeups">Writeups</a>
            <a href="#contact" className="hover:text-primary transition-colors" data-testid="nav-contact">Contact</a>
            <button 
              onClick={toggleTheme}
              className="text-xl hover:text-primary transition-colors"
              data-testid="theme-toggle"
            >
              <i className={`fas ${theme === 'dark' ? 'fa-sun' : 'fa-moon'}`}></i>
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="md:hidden flex items-center gap-4">
            <button 
              onClick={toggleTheme}
              className="text-xl hover:text-primary transition-colors"
              data-testid="theme-toggle-mobile"
            >
              <i className={`fas ${theme === 'dark' ? 'fa-sun' : 'fa-moon'}`}></i>
            </button>
            <button 
              onClick={handleMobileMenuToggle}
              className="text-2xl hover:text-primary transition-colors"
              data-testid="mobile-menu-button"
            >
              <i className="fas fa-bars"></i>
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <div 
        className={`mobile-menu fixed inset-0 bg-background flex-col items-center justify-center gap-8 text-xl z-40 ${
          isMobileMenuOpen ? 'active' : ''
        }`}
        data-testid="mobile-menu"
      >
        <button 
          onClick={handleMobileMenuClose}
          className="absolute top-6 right-6 text-3xl hover:text-primary"
          data-testid="mobile-menu-close"
        >
          <i className="fas fa-times"></i>
        </button>
        <a href="#home" className="hover:text-primary transition-colors" onClick={handleMobileMenuClose}>Home</a>
        <a href="#about" className="hover:text-primary transition-colors" onClick={handleMobileMenuClose}>About</a>
        <a href="#skills" className="hover:text-primary transition-colors" onClick={handleMobileMenuClose}>Skills</a>
        <a href="#achievements" className="hover:text-primary transition-colors" onClick={handleMobileMenuClose}>Achievements</a>
        <a href="#projects" className="hover:text-primary transition-colors" onClick={handleMobileMenuClose}>Projects</a>
        <a href="#writeups" className="hover:text-primary transition-colors" onClick={handleMobileMenuClose}>Writeups</a>
        <a href="#contact" className="hover:text-primary transition-colors" onClick={handleMobileMenuClose}>Contact</a>
      </div>
    </>
  );
}
