import { useEffect, useState } from "react";
import { useTypingEffect } from "@/hooks/use-typing-effect";

export default function HeroSection() {
  const typedText = useTypingEffect([
    'Bug Bounty Hunter',
    'Security Researcher', 
    'Cybersecurity Enthusiast',
    'Web Pentester'
  ], 100, 50, 2000);

  return (
    <section id="home" className="min-h-screen flex items-center justify-center pt-20" data-testid="hero-section">
      <div className="text-center animate-slide-up">
        {/* Profile Image */}
        <div className="mb-8">
          <div className="w-40 h-40 mx-auto rounded-full border-4 border-primary overflow-hidden glow-green">
            <img 
              src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400" 
              alt="Sadik Mahmud Profile" 
              className="w-full h-full object-cover"
              data-testid="profile-image"
            />
          </div>
        </div>

        {/* Name & Title */}
        <h1 className="text-4xl md:text-6xl font-display font-bold mb-4" data-testid="hero-name">
          <span className="gradient-text">Sadik Mahmud</span>
        </h1>
        <p className="text-xl md:text-2xl text-muted-foreground mb-2" data-testid="hero-username">
          @sadik0x01
        </p>
        
        {/* Typing Animation */}
        <div className="h-16 flex items-center justify-center mb-8">
          <p className="text-lg md:text-xl text-primary" data-testid="typed-text">
            {typedText}
          </p>
        </div>

        {/* View Resume Button */}
        <a 
          href="#" 
          target="_blank" 
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-8 py-3 rounded-lg font-bold hover:bg-accent transition-all hover:scale-105 mb-12"
          data-testid="resume-button"
        >
          <i className="fas fa-file-alt"></i>
          <span>View Resume</span>
        </a>

        {/* Social Links */}
        <div className="flex justify-center gap-4 flex-wrap" data-testid="social-links">
          <a 
            href="https://x.com/sadik0x01" 
            target="_blank" 
            rel="noopener noreferrer"
            className="social-icon" 
            title="Twitter/X"
            data-testid="social-twitter"
          >
            <i className="fab fa-twitter text-xl"></i>
          </a>
          <a 
            href="https://linkedin.com/in/sadik0x01" 
            target="_blank" 
            rel="noopener noreferrer"
            className="social-icon" 
            title="LinkedIn"
            data-testid="social-linkedin"
          >
            <i className="fab fa-linkedin text-xl"></i>
          </a>
          <a 
            href="https://github.com/sadik0x01" 
            target="_blank" 
            rel="noopener noreferrer"
            className="social-icon" 
            title="GitHub"
            data-testid="social-github"
          >
            <i className="fab fa-github text-xl"></i>
          </a>
          <a 
            href="http://discord.com/users/1033024826799030312" 
            target="_blank" 
            rel="noopener noreferrer"
            className="social-icon" 
            title="Discord"
            data-testid="social-discord"
          >
            <i className="fab fa-discord text-xl"></i>
          </a>
          <a 
            href="https://app.hackthebox.com/profile/1314761" 
            target="_blank" 
            rel="noopener noreferrer"
            className="social-icon" 
            title="Hack The Box"
            data-testid="social-hackthebox"
          >
            <i className="fas fa-cube text-xl"></i>
          </a>
          <a 
            href="https://sadik0x01.medium.com" 
            target="_blank" 
            rel="noopener noreferrer"
            className="social-icon" 
            title="Medium"
            data-testid="social-medium"
          >
            <i className="fab fa-medium text-xl"></i>
          </a>
          <a 
            href="https://www.facebook.com/sadik0x01" 
            target="_blank" 
            rel="noopener noreferrer"
            className="social-icon" 
            title="Facebook"
            data-testid="social-facebook"
          >
            <i className="fab fa-facebook text-xl"></i>
          </a>
          <a 
            href="mailto:sadikm0x01@gmail.com" 
            className="social-icon" 
            title="Email"
            data-testid="social-email"
          >
            <i className="fas fa-envelope text-xl"></i>
          </a>
        </div>
      </div>
    </section>
  );
}
