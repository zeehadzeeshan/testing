export default function WriteupsSection() {
  return (
    <section id="writeups" className="py-20 bg-muted/50" data-testid="writeups-section">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-display font-bold text-center mb-16 gradient-text">
          Security Writeups
        </h2>
        
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-card p-12 rounded-xl border border-border hover-lift">
            <i className="fab fa-medium text-6xl text-primary mb-6"></i>
            <h3 className="text-2xl font-bold text-card-foreground mb-4">Visit My Medium Blog</h3>
            <p className="text-card-foreground mb-8">Read my latest security writeups and research articles</p>
            <a 
              href="https://sadik0x01.medium.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-8 py-3 rounded-lg font-bold hover:bg-accent transition-all hover:scale-105"
              data-testid="medium-blog-link"
            >
              <i className="fas fa-book-open"></i>
              <span>Read Articles</span>
            </a>
            <p className="text-muted-foreground text-sm mt-6">
              Latest Posts - Follow me on Medium to stay updated with my latest findings
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
