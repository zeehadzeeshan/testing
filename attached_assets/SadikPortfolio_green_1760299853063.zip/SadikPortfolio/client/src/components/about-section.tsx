export default function AboutSection() {
  return (
    <section id="about" className="py-20" data-testid="about-section">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-display font-bold text-center mb-16 gradient-text">
          About Me
        </h2>
        
        <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Bio */}
          <div className="bg-card p-8 rounded-xl border border-border hover-lift" data-testid="bio-card">
            <h3 className="text-2xl font-bold text-primary mb-6">Who I Am</h3>
            <p className="text-card-foreground leading-relaxed">
              As an ethical hacker and dedicated bug bounty hunter, I specialize in uncovering and addressing critical security vulnerabilities across Web applications, Mobile apps, and APIs. My approach involves rigorous Vulnerability Assessments and Penetration Testing, aimed at strengthening an organization's digital defenses.
            </p>
            <p className="text-card-foreground leading-relaxed mt-4">
              Driven by a profound passion for cybersecurity, I actively work to find and fix flaws, thereby enhancing overall digital safety and fostering a more secure online ecosystem.
            </p>
          </div>

          {/* Basic Info */}
          <div className="bg-card p-8 rounded-xl border border-border hover-lift" data-testid="info-card">
            <h3 className="text-2xl font-bold text-secondary mb-6">Basic Information</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-4" data-testid="info-email">
                <i className="fas fa-envelope text-primary text-xl mt-1"></i>
                <div>
                  <p className="text-muted-foreground text-sm">Email</p>
                  <p className="text-card-foreground">sadikm0x01@gmail.com</p>
                </div>
              </div>
              <div className="flex items-start gap-4" data-testid="info-location">
                <i className="fas fa-map-marker-alt text-primary text-xl mt-1"></i>
                <div>
                  <p className="text-muted-foreground text-sm">Location</p>
                  <p className="text-card-foreground">Dhaka, Bangladesh</p>
                </div>
              </div>
              <div className="flex items-start gap-4" data-testid="info-specialization">
                <i className="fas fa-user-shield text-primary text-xl mt-1"></i>
                <div>
                  <p className="text-muted-foreground text-sm">Specialization</p>
                  <p className="text-card-foreground">Bug Bounty Hunter, Security Researcher, Web Pentester</p>
                </div>
              </div>
              <div className="flex items-start gap-4" data-testid="info-languages">
                <i className="fas fa-language text-primary text-xl mt-1"></i>
                <div>
                  <p className="text-muted-foreground text-sm">Languages</p>
                  <p className="text-card-foreground">English, Bangla, Hindi, Urdu</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
