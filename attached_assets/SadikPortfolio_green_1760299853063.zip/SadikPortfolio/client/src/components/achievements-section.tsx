export default function AchievementsSection() {
  const achievements = [
    {
      company: "Google",
      title: "Bug Reported & Awarded By Google",
      description: "Security Researcher Recognition",
      icon: "fab fa-google",
      color: "text-primary",
      link: "#"
    },
    {
      company: "Google",
      title: "Google Honorable Mentions",
      description: "Featured in Security Hall of Fame",
      icon: "fab fa-google",
      color: "text-secondary",
      link: "#"
    },
    {
      company: "Facebook",
      title: "Bug Reported & Awarded By Facebook",
      description: "Bug Bounty Recognition",
      icon: "fab fa-facebook",
      color: "text-primary",
      link: "#"
    },
    {
      company: "Microsoft",
      title: "Acknowledged by Microsoft",
      description: "Security Researcher Program",
      icon: "fab fa-microsoft",
      color: "text-secondary",
      link: "#"
    },
    {
      company: "Adobe",
      title: "Adobe Hall of Fame",
      description: "Security Acknowledgment",
      icon: "fas fa-trophy",
      color: "text-primary",
      link: "#"
    },
    {
      company: "Sony",
      title: "Received Swag From Sony",
      description: "Bug Bounty Reward",
      icon: "fas fa-gift",
      color: "text-secondary",
      link: "#"
    }
  ];

  return (
    <section id="achievements" className="py-20" data-testid="achievements-section">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-display font-bold text-center mb-16 gradient-text">
          Achievements
        </h2>
        
        <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-6">
          {achievements.map((achievement, index) => (
            <a 
              key={index}
              href={achievement.link} 
              className="achievement-card bg-card p-6 rounded-xl border border-border hover-lift block"
              data-testid={`achievement-${index}`}
            >
              <div className="flex items-center gap-4">
                <i className={`${achievement.icon} text-4xl ${achievement.color}`}></i>
                <div>
                  <h3 className="text-xl font-bold text-card-foreground">{achievement.title}</h3>
                  <p className="text-muted-foreground text-sm">{achievement.description}</p>
                </div>
              </div>
            </a>
          ))}
        </div>
        
        <div className="text-center mt-8">
          <p className="text-muted-foreground text-sm">
            {/* Add your achievement links in the HTML when available */}
          </p>
        </div>
      </div>
    </section>
  );
}
