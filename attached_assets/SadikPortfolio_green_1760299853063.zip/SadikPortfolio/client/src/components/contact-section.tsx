import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface ContactForm {
  name: string;
  email: string;
  message: string;
}

export default function ContactSection() {
  const [formData, setFormData] = useState<ContactForm>({
    name: '',
    email: '',
    message: ''
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const submitContact = useMutation({
    mutationFn: async (data: ContactForm) => {
      const response = await apiRequest("POST", "/api/contact", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Message Sent!",
        description: "Thank you for your message. I'll get back to you soon.",
      });
      setFormData({ name: '', email: '', message: '' });
      queryClient.invalidateQueries({ queryKey: ['/api/contacts'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      toast({
        title: "Error",
        description: "Please fill in all fields.",
        variant: "destructive",
      });
      return;
    }
    submitContact.mutate(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section id="contact" className="py-20" data-testid="contact-section">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-display font-bold text-center mb-4 gradient-text">
          Get In Touch
        </h2>
        <p className="text-center text-2xl text-foreground mb-16">Don't Be Shy — Say Hi! 👋</p>
        
        <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="bg-card p-8 rounded-xl border border-border">
            <h3 className="text-2xl font-bold text-primary mb-6">Send a Message</h3>
            <form onSubmit={handleSubmit} className="space-y-4" data-testid="contact-form">
              <div>
                <label className="block text-muted-foreground mb-2 text-sm">Name</label>
                <Input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Your Name"
                  data-testid="input-name"
                />
              </div>
              <div>
                <label className="block text-muted-foreground mb-2 text-sm">Email</label>
                <Input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="your.email@example.com"
                  data-testid="input-email"
                />
              </div>
              <div>
                <label className="block text-muted-foreground mb-2 text-sm">Message</label>
                <Textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  placeholder="Your message here..."
                  data-testid="input-message"
                />
              </div>
              <Button 
                type="submit" 
                className="w-full bg-primary hover:bg-accent text-primary-foreground"
                disabled={submitContact.isPending}
                data-testid="button-submit"
              >
                {submitContact.isPending ? 'Sending...' : 'Send Message'}
              </Button>
            </form>
          </div>

          {/* Contact Info */}
          <div className="space-y-6">
            <div className="bg-card p-6 rounded-xl border border-border hover-lift" data-testid="contact-email">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                  <i className="fas fa-envelope text-primary text-xl"></i>
                </div>
                <div>
                  <p className="text-muted-foreground text-sm">Email</p>
                  <a 
                    href="mailto:sadikm0x01@gmail.com" 
                    className="text-card-foreground hover:text-primary transition-colors"
                  >
                    sadikm0x01@gmail.com
                  </a>
                </div>
              </div>
            </div>

            <div className="bg-card p-6 rounded-xl border border-border hover-lift" data-testid="contact-location">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-secondary/20 rounded-lg flex items-center justify-center">
                  <i className="fas fa-map-marker-alt text-secondary text-xl"></i>
                </div>
                <div>
                  <p className="text-muted-foreground text-sm">Location</p>
                  <p className="text-card-foreground">Dhaka, Bangladesh</p>
                </div>
              </div>
            </div>

            <div className="bg-card p-6 rounded-xl border border-border" data-testid="contact-socials">
              <h4 className="text-lg font-bold text-primary mb-4">Connect With Me</h4>
              <div className="flex flex-wrap gap-3">
                <a href="https://x.com/sadik0x01" target="_blank" rel="noopener noreferrer" className="social-icon">
                  <i className="fab fa-twitter"></i>
                </a>
                <a href="https://linkedin.com/in/sadik0x01" target="_blank" rel="noopener noreferrer" className="social-icon">
                  <i className="fab fa-linkedin"></i>
                </a>
                <a href="https://github.com/sadik0x01" target="_blank" rel="noopener noreferrer" className="social-icon">
                  <i className="fab fa-github"></i>
                </a>
                <a href="https://www.facebook.com/sadik0x01" target="_blank" rel="noopener noreferrer" className="social-icon">
                  <i className="fab fa-facebook"></i>
                </a>
                <a href="https://sadik0x01.medium.com" target="_blank" rel="noopener noreferrer" className="social-icon">
                  <i className="fab fa-medium"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
