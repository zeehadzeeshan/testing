import { type Dork, type InsertDork, type Contact, type InsertContact } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Dork operations
  getDorksByType(type: string): Promise<Dork[]>;
  createDork(dork: InsertDork): Promise<Dork>;
  searchDorks(type: string, query: string): Promise<Dork[]>;
  
  // Contact operations
  createContact(contact: InsertContact): Promise<Contact>;
  getContacts(): Promise<Contact[]>;
}

export class MemStorage implements IStorage {
  private dorks: Map<string, Dork>;
  private contacts: Map<string, Contact>;

  constructor() {
    this.dorks = new Map();
    this.contacts = new Map();
    this.initializeDorks();
  }

  private initializeDorks() {
    // GitHub Dorks (duplicates removed)
    const githubDorks = [
      'filename:.env',
      'filename:config.php database',
      'filename:wp-config.php',
      'filename:database.yml',
      'filename:prod.exs',
      'filename:configuration.php JConfig password',
      'filename:config.inc.php',
      'extension:sql mysql dump',
      'extension:sql "INSERT INTO" password',
      'extension:json mongolab.com',
      'extension:yaml mongolab.com',
      'extension:ica',
      'filename:shadow',
      'filename:passwd',
      'filename:dbeaver-data-sources.xml',
      'filename:sftp-config.json',
      'filename:secrets.yml password',
      'filename:master.key path:config',
      'filename:deployment-config.json',
      'shodan_api_key',
      'filename:WebServers.xml',
      'filename:.esmtprc password',
      'filename:.netrc password',
      'filename:_netrc password',
      'filename:hub oauth_token',
      'filename:.dockercfg',
      'filename:config.json auths',
      'extension:avastlic "support.avast.com"',
      'extension:json api.forecast.io',
      'extension:json mongolab.com',
      'extension:yaml mongolab.com',
      'HEROKU_API_KEY language:shell',
      'HEROKU_API_KEY language:json',
      'SF_USERNAME salesforce',
      'filename:beaglesecurity_token',
      'filename:tugboat NOT "_tugboat"',
      'filename:.tugboat NOT "_tugboat"',
      'filename:proftpdpasswd',
      'filename:ventrilo_srv.ini',
      'filename:etc/passwd',
      'filename:etc/shadow',
      'path:sites databases password',
      'shodan_api_key language:python',
      'shodan_api_key language:shell',
      'shodan_api_key language:json',
      'filename:logins.json',
      'filename:CCCam.cfg',
      'msg nickserv identify filename:config',
      'filename:settings.py SECRET_KEY',
      'filename:secrets.yml password',
      'filename:master.key path:config',
      'filename:.env DB_PASSWORD',
      'filename:.env MAIL_PASSWORD',
      'filename:prod.secret.exs',
      'filename:configuration.php JConfig password',
      'filename:config.inc.php',
      'extension:pem private',
      'extension:ppk private',
      'filename:id_rsa',
      'filename:id_dsa',
      'filename:.htpasswd',
      'filename:password.txt',
      'filename:passwords.txt',
      'filename:accounts.txt',
      'filename:credentials.txt',
      'filename:secret.txt',
      'filename:config.php password',
      'filename:wp-config.php DB_PASSWORD'
    ];

    // Shodan Dorks (duplicates removed) 
    const shodanDorks = [
      'ssl:"target.com" http.html:"Login, username, password"',
      'http.title:"Admin"',
      'ssl:"target.com" org:"Cloudflare, Inc." product:"nginx" 200',
      'kibana content-length:217',
      'org:"Amazon" ssl:"target"',
      'html:"Dashboard Jenkins" http.component:"jenkins"',
      'http.title:"302 Found"',
      'X-Amz-Bucket-Region',
      'x-jenkins 200',
      'X-Generator: Drupal 7',
      'ssl:Google',
      'all:"mongodb server information" all:"metrics"',
      'port:27017 -all:"partially" all:"fs.files"',
      'port:"9200" all:"elastic indices"',
      'product:elastic port:9200',
      'product: CouchDB',
      'title:"system dashboard" html:jira',
      'product: "apache tomcat"',
      'http.component:ruby port:3000',
      'html:"secret_key_base"',
      'html:"rack.version"',
      'http.favicon.hash:81586312 200',
      'html:/dana-na/ Pulse Secure VPN exploit',
      '"MongoDB Server Information" port:27017 -authentication',
      '"Set-Cookie: mongo-express=" "200 OK"',
      'mysql port:"3306"',
      'port:5432 PostgreSQL',
      '"220" "230 Login successful." port:21',
      'proftpd port:21',
      'port:"25" product:"exim"',
      'port:"11211" product:"Memcached"',
      '"X-Jenkins" "Set-Cookie: JSESSIONID" http.title:"Dashboard"',
      '"port: 53" Recursion: Enabled',
      'product:"Apache httpd" port:"80"',
      'product:"Microsoft IIS httpd"',
      'ssl.cert.expired:true',
      '"Authentication: disabled" port:445',
      'asn:AS6185',
      'Server: SQ-WEBCAM',
      'html: "AWS Elastic Beanstalk overview"',
      'html: "AWS_ACCESS_KEY_ID"',
      'html: "AWS_SECRET_ACCESS_KEY"',
      'html: "OpenSearch Dashboards"',
      'port: "23"',
      'port:8291 os: "MikroTik RouterOS 6.45.9"',
      'product: "SimpleHTTPServer"',
      'ssl.cert.issuer.cn:example.com ssl.cert.subject.cn:example.com',
      'title: "Directory listing for /"',
      'title: "AWS S3 Explorer"',
      'http.title:"Grafana" 200',
      'org:"Hilton International Holding LLC"',
      'ssl:"Facebook Inc."',
      'hostname:target.com',
      'title:"Login — Adminer"',
      'http.title:"sign up"',
      'http.title:"LogIn"',
      'title:"401 Authorization Required"',
      'http.html:"403 Forbidden"',
      'http.html:"500 Internal Server Error"',
      'ssl.cert.subject.cn:*vpn*',
      'title:"citrix gateway"',
      'http.html:"JFrog"',
      'http.title:"dashboard"',
      'http.title:"Openfire Admin Console"',
      'http.title:"control panel"',
      'clockwork',
      '"Server: Jetty"',
      'product:"Kubernetes" port:"10250, 2379"',
      'port:"9100" http.title:"Node Exporter"',
      'http.title:"RabbitMQ"',
      'HTTP/1.1 307 Temporary Redirect "Location: /containers"',
      'http.favicon.hash:1278323681',
      'title:"kibana"',
      'port:9090 http.title:"Prometheus Time Series Collection and Processing Server"',
      '"default password"',
      'title:protected',
      'http.component:Moodle',
      'html:"/login/?next=" title:"Django"',
      'html:"/admin/login/?next=" title:"Django"',
      '"netweaver"',
      'port:"2379" product:"etcd"',
      'http.title:"DisallowedHost"'
    ];

    // Google Dorks
    const googleDorks = [
      'site:target.com filetype:pdf',
      'site:target.com inurl:admin',
      'site:target.com inurl:login',
      'site:target.com intitle:"index of"',
      'site:target.com filetype:sql',
      'site:target.com filetype:log',
      'site:target.com inurl:backup',
      'site:target.com filetype:bak',
      'site:target.com "database" filetype:sql',
      'site:target.com inurl:wp-admin',
      'site:target.com inurl:wp-content',
      'site:target.com filetype:env',
      'site:target.com "password" filetype:txt',
      'site:target.com intitle:"login" inurl:login',
      'site:target.com "confidential" filetype:pdf',
      'site:target.com "secret" OR "password" filetype:xls',
      'site:target.com inurl:config',
      'site:target.com "api key" OR "api_key"',
      'site:target.com inurl:upload',
      'site:target.com intitle:"dashboard"',
      'site:target.com inurl:admin.php',
      'site:target.com "mysql" OR "database"',
      'site:target.com filetype:config',
      'site:target.com "email" AND "password"',
      'site:target.com inurl:shell',
      'site:target.com "ftp" AND "password"',
      'site:target.com filetype:backup',
      'site:target.com "username" AND "password"',
      'site:target.com intitle:"phpMyAdmin"',
      'site:target.com "server" AND "error"'
    ];

    // Bug Bounty Dorks
    const bugbountyDorks = [
      'inurl:"bug bounty"',
      'inurl:"vulnerability disclosure"',
      'inurl:"security program"',
      'inurl:"responsible disclosure"',
      'site:bugcrowd.com',
      'site:hackerone.com',
      'site:yeswehack.com',
      '"bug bounty program"',
      '"security researcher"',
      '"vulnerability reward program"',
      '"responsible disclosure program"',
      'intext:"submit security vulnerability"',
      'intext:"security contact"',
      'inurl:"security.txt"',
      'inurl:".well-known/security.txt"',
      '"security team" contact',
      '"report vulnerability"',
      '"security hall of fame"',
      'inurl:"hall-of-fame"',
      '"coordinated disclosure"',
      '"security advisory"',
      'intext:"security researchers"',
      'inurl:"security-policy"',
      '"vulnerability submission"',
      'site:openbugbounty.org',
      'site:intigriti.com',
      'site:safehats.com',
      '"white hat" program',
      'inurl:"responsible-disclosure"',
      '"security acknowledgments"'
    ];

    // Initialize GitHub dorks
    githubDorks.forEach((query, index) => {
      const id = randomUUID();
      this.dorks.set(id, {
        id,
        type: 'github',
        query,
        description: `GitHub search query ${index + 1}`,
        category: 'general'
      });
    });

    // Initialize Shodan dorks
    shodanDorks.forEach((query, index) => {
      const id = randomUUID();
      this.dorks.set(id, {
        id,
        type: 'shodan',
        query,
        description: `Shodan search query ${index + 1}`,
        category: 'general'
      });
    });

    // Initialize Google dorks
    googleDorks.forEach((query, index) => {
      const id = randomUUID();
      this.dorks.set(id, {
        id,
        type: 'google',
        query,
        description: `Google search query ${index + 1}`,
        category: 'general'
      });
    });

    // Initialize Bug Bounty dorks
    bugbountyDorks.forEach((query, index) => {
      const id = randomUUID();
      this.dorks.set(id, {
        id,
        type: 'bugbounty',
        query,
        description: `Bug bounty search query ${index + 1}`,
        category: 'general'
      });
    });
  }

  async getDorksByType(type: string): Promise<Dork[]> {
    return Array.from(this.dorks.values()).filter(dork => dork.type === type);
  }

  async createDork(insertDork: InsertDork): Promise<Dork> {
    const id = randomUUID();
    const dork: Dork = { 
      id,
      type: insertDork.type,
      query: insertDork.query,
      description: insertDork.description || null,
      category: insertDork.category || null
    };
    this.dorks.set(id, dork);
    return dork;
  }

  async searchDorks(type: string, query: string): Promise<Dork[]> {
    const allDorks = await this.getDorksByType(type);
    if (!query.trim()) return allDorks;
    
    return allDorks.filter(dork => 
      dork.query.toLowerCase().includes(query.toLowerCase()) ||
      (dork.description && dork.description.toLowerCase().includes(query.toLowerCase()))
    );
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const contact: Contact = { 
      ...insertContact, 
      id,
      createdAt: new Date().toISOString()
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values());
  }
}

export const storage = new MemStorage();
