import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get dorks by type
  app.get("/api/dorks/:type", async (req, res) => {
    try {
      const { type } = req.params;
      const dorks = await storage.getDorksByType(type);
      res.json(dorks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dorks" });
    }
  });

  // Search dorks
  app.get("/api/dorks/:type/search", async (req, res) => {
    try {
      const { type } = req.params;
      const { q } = req.query;
      const dorks = await storage.searchDorks(type, q as string || '');
      res.json(dorks);
    } catch (error) {
      res.status(500).json({ message: "Failed to search dorks" });
    }
  });

  // Submit contact form
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(validatedData);
      res.json({ message: "Contact form submitted successfully", contact });
    } catch (error) {
      res.status(400).json({ message: "Invalid contact data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
