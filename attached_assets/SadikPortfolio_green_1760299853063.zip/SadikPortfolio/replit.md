# Bug Bounty Toolkit Portfolio

## Overview

This is a personal portfolio and security research toolkit for a bug bounty hunter and security researcher. The application provides a curated collection of security dorks (specialized search queries) for various platforms including GitHub, Shodan, Google, and bug bounty programs. It also serves as a professional portfolio showcasing skills, achievements, and security research writeups.

The application is designed to help security researchers and penetration testers quickly access and search through categorized dork collections to discover potential vulnerabilities and security issues across different platforms.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server
- Wouter for lightweight client-side routing
- TailwindCSS for utility-first styling with custom design tokens
- Shadcn/ui component library built on Radix UI primitives

**Design System:**
- Dark theme as default with custom cybersecurity aesthetic
- Custom color palette featuring neon green (#00ff88) and purple accents
- Typography using JetBrains Mono for code/monospace text and Orbitron for display headings
- Particle.js integration for animated background effects
- Responsive design with mobile-first approach

**State Management:**
- TanStack Query (React Query) for server state management and caching
- Local React state for UI interactions
- Context API for theme management (dark/light mode)

**Key Features:**
- Animated intro sequence with spider icon branding
- Typing effect animation for hero section
- Smooth scroll navigation with anchor links
- Search and filter functionality for dork collections
- Contact form with validation
- Portfolio sections: About, Skills, Achievements, Projects, Writeups

### Backend Architecture

**Technology Stack:**
- Express.js server running on Node.js
- TypeScript for type safety across the stack
- ESM modules for modern JavaScript imports

**API Design:**
- RESTful API endpoints for dork retrieval and search
- Route structure:
  - `GET /api/dorks/:type` - Fetch dorks by type (github, shodan, google, bugbounty, recon)
  - `GET /api/dorks/:type/search?q=query` - Search within dork type
  - `POST /api/contact` - Submit contact form

**Data Storage:**
- In-memory storage implementation (MemStorage class) for development
- Data is initialized from curated lists of security dorks
- Ready for database integration with Drizzle ORM schema defined

**Request Handling:**
- JSON body parsing with raw body capture
- Request logging middleware for API calls
- Error handling with appropriate HTTP status codes

### Data Storage Solutions

**Current Implementation:**
- In-memory Map-based storage for dorks and contacts
- Pre-populated with curated security dork collections from text files

**Database Schema (PostgreSQL via Drizzle ORM):**
- `dorks` table: Stores security search queries with categorization
  - id (UUID primary key)
  - type (text) - Platform type: github, shodan, google, bugbounty, recon
  - query (text) - The actual search query/dork
  - description (text, optional) - Explanation of what the dork finds
  - category (text, optional) - Subcategory for filtering

- `contacts` table: Stores contact form submissions
  - id (UUID primary key)
  - name (text)
  - email (text)
  - message (text)
  - createdAt (timestamp)

**Migration Strategy:**
- Drizzle Kit configured for PostgreSQL migrations
- Schema validation using Drizzle-Zod for runtime type checking
- Connection via environment variable DATABASE_URL

### External Dependencies

**Database:**
- Neon Serverless PostgreSQL (@neondatabase/serverless)
- Drizzle ORM for type-safe database queries
- Connection pooling ready for production deployment

**UI Component Libraries:**
- Radix UI primitives for accessible, unstyled components (25+ components)
- Shadcn/ui component system built on top of Radix
- Lucide React for iconography
- Font Awesome 6 via CDN for additional icons

**Development Tools:**
- Vite with React plugin for HMR and fast builds
- Replit-specific plugins for error overlay and cartographer
- ESBuild for server-side bundling in production

**Third-Party Services:**
- Particles.js from CDN for background animations
- Google Fonts for typography (Inter, Roboto, JetBrains Mono, Orbitron)
- External search engines (Google, Shodan, GitHub) for dork execution

**Form Handling:**
- React Hook Form for form state management
- Zod for schema validation via @hookform/resolvers

**Deployment Considerations:**
- Environment-based configuration (NODE_ENV)
- Static file serving in production
- Database connection via DATABASE_URL environment variable
- Session management ready with connect-pg-simple (PostgreSQL session store)