# Bug Bounty Portfolio & Dork Tools

## Overview

This is a cybersecurity-focused web application that serves dual purposes: a personal portfolio for a bug bounty hunter (Sadik Mahmud - @sadik0x01) and a collection of reconnaissance/dork search tools for security researchers. The application features a "cybersunk" aesthetic (cyberpunk + minimalism) for the portfolio sections while maintaining utility-first design principles for the tool pages.

The application provides five main tool categories:
- **Google Dorks**: Pre-configured search queries for discovering vulnerabilities via Google
- **GitHub Dorks**: Queries for finding exposed secrets and sensitive data on GitHub
- **Shodan Dorks**: Specialized searches for IoT devices and exposed services via Shodan
- **Bug Bounty Dorks**: Focused searches for discovering bug bounty programs
- **Recon Methodology**: Comprehensive toolkit and methodology for security reconnaissance

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18 with TypeScript, built using Vite as the bundler.

**Routing**: Wouter for lightweight client-side routing with the following page structure:
- `/` - Portfolio home page with contact form
- `/google-dorks` - Google dork search tool
- `/github-dorks` - GitHub dork search tool  
- `/shodan-dorks` - Shodan dork search tool
- `/bug-bounty-dorks` - Bug bounty program finder
- `/recon` - Reconnaissance methodology guide

**UI Components**: Radix UI primitives with shadcn/ui component library, heavily customized for the cybersunk aesthetic.

**Styling**: Tailwind CSS with custom design tokens defined in CSS variables. Implements a dual-theme system:
- Dark mode as default (deep space black backgrounds with neon green/purple accents)
- Light mode with professional white/gray backgrounds
- Tool-specific accent colors (vapor green for Google, purple/lime for GitHub, neon red for Shodan, magenta for Bug Bounty)

**Typography**: Custom font stack:
- Orbitron (700, 900) for headings and branding
- JetBrains Mono for code/technical content
- Montserrat (400, 600, 700) for body text
- Merienda One for retro-styled Shodan page

**State Management**: React Query (TanStack Query v5) for server state and form handling with React Hook Form + Zod validation.

**Visual Effects**: Particles.js integration for animated particle backgrounds on portfolio pages, creating the cyberpunk aesthetic.

### Backend Architecture

**Runtime**: Node.js with Express.js server framework.

**API Design**: RESTful API with single endpoint `/api/contact` for form submissions.

**Build System**: 
- Frontend: Vite with React plugin, TypeScript compilation
- Backend: esbuild for bundling server code as ESM
- Development: tsx for TypeScript execution in dev mode

**Session & Storage**: In-memory storage implementation (MemStorage class) for user data, designed to be swapped with database persistence.

**Development Tools**: 
- Replit-specific plugins for development banner and cartographer
- Runtime error overlay for better DX
- Custom logging middleware for API request tracking

### Data Layer

**ORM**: Drizzle ORM configured for PostgreSQL (via Neon serverless driver).

**Schema Design**: 
- Users table with UUID primary keys
- Contact message validation schema using Drizzle-Zod integration
- Type-safe database operations with full TypeScript inference

**Database Config**: Drizzle Kit configured for schema migrations with PostgreSQL dialect, expecting DATABASE_URL environment variable.

**Current State**: Database schema defined but application currently uses in-memory storage. Database integration is prepared but not actively used - likely intended for future user authentication or persistent storage features.

### Design System Philosophy

**Progressive Disclosure**: Card-based layouts that reveal information hierarchically.

**Responsive Design**: Mobile-first approach with collapsible navigation and adaptive layouts.

**Accessibility**: Radix UI primitives ensure WCAG compliance with proper ARIA attributes and keyboard navigation.

**Visual Hierarchy**: 
- Portfolio pages use dramatic shadows, glows, and animations
- Tool pages prioritize clean Material Design principles with clear CTAs
- Consistent color coding across tools for quick visual identification

## External Dependencies

### Core Framework Dependencies
- **React 18** - UI library
- **TypeScript** - Type safety
- **Vite** - Build tool and dev server
- **Express.js** - Backend server framework
- **Wouter** - Lightweight routing

### Database & ORM
- **@neondatabase/serverless** - Neon PostgreSQL serverless driver
- **Drizzle ORM** - Type-safe SQL toolkit
- **drizzle-zod** - Zod schema generation from Drizzle schemas

### UI Component Libraries
- **Radix UI** - Headless component primitives (20+ components including Dialog, Dropdown, Toast, etc.)
- **shadcn/ui** - Pre-styled Radix components following the New York style variant
- **Tailwind CSS** - Utility-first CSS framework
- **class-variance-authority** - CSS variant management
- **cmdk** - Command palette component

### Form Handling & Validation
- **React Hook Form** - Form state management
- **@hookform/resolvers** - Validation resolver integration
- **Zod** - Schema validation

### Data Fetching
- **TanStack React Query v5** - Server state management and caching

### Visual Effects
- **Particles.js** - Particle animation backgrounds for cyberpunk aesthetic

### Development Tools
- **@replit/vite-plugin-runtime-error-modal** - Enhanced error reporting
- **@replit/vite-plugin-cartographer** - Replit development tooling
- **@replit/vite-plugin-dev-banner** - Development environment indicators

### Build Dependencies
- **esbuild** - Fast JavaScript bundler for server code
- **tsx** - TypeScript execution engine for development
- **PostCSS** - CSS transformation with Tailwind
- **Autoprefixer** - CSS vendor prefixing

### External Services (Used via Client-Side Links)
- **Google Search** - Dork query execution
- **GitHub Search** - Code and gist searching
- **Shodan** - IoT/device search engine
- **Social Media Platforms** - Twitter, LinkedIn, Facebook, Discord for contact links
- **HackTheBox** - Security training platform profile
- **Medium** - Blog platform for writeups