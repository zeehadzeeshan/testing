# Design Guidelines: Bug Bounty Portfolio & Dork Tools

## Design System

**Approach:** Hybrid design - Portfolio uses cybersecurity aesthetics for brand identity; tool pages prioritize utility with Material Design principles.

**Core Principles:**
1. Cybersunk aesthetic (cyberpunk + minimalism)
2. Trust through clean, functional interfaces
3. Progressive disclosure via card layouts
4. Responsive professionalism across devices

## Color System

### Dark Mode (Default)
```css
--bg-primary: #0d1117;        /* Deep space black */
--bg-secondary: #090c10;      /* Darker panels */
--accent-primary: #00dc82;    /* Matrix green */
--accent-secondary: #8a0964;  /* Deep purple */
--text-primary: #c9d1d9;      /* Light grey */
--text-muted: #8b949e;        /* Medium grey */
```

### Light Mode
```css
--bg-primary: #ffffff;
--bg-secondary: #f8f9fa;
--text-primary: #1a1a1a;
/* Accents remain unchanged */
```

### Tool-Specific Accents
- **Google Dorks:** #00dc82 (vapor green)
- **GitHub Dorks:** #4a2aa8 (purple) + #aeda11 (lime)
- **Shodan Dorks:** #dc4334 (neon red)
- **Bug Bounty Dorks:** #af007b (magenta)
- **Recon:** #00dc82 (matrix green)

## Typography

**Fonts:**
- Headings/Brand: 'Orbitron' (700, 900)
- Code/Technical: 'JetBrains Mono'
- Body/UI: 'Montserrat' (400, 600, 700)
- Retro (Shodan): 'Merienda One'

**Scale:**
- H1: 2.5-3rem, Orbitron 900, letter-spacing 3px, text-shadow glow
- H2: 2-2.5rem, Orbitron 700
- H3: 1.5rem, Montserrat 600
- Body: 1rem, Montserrat 400, line-height 1.6
- Code: 0.9-1rem, JetBrains Mono

## Layout

**Spacing:** Tailwind units - 4, 8, 16, 24, 32 (1-8rem)
- Component padding: p-8 to p-16
- Section spacing: py-20 to py-32
- Card gaps: gap-4 to gap-8

**Containers:**
- Portfolio: max-w-7xl (1280px)
- Tools: max-w-6xl (1152px)
- Cards: 2-3 cols desktop, 1 col mobile

**Breakpoints:** <768px mobile, 768-1024px tablet, >1024px desktop

## Components

### Navigation
- Fixed header, 4rem height, z-1000, dark blur background
- Logo: Spider icon + green glow + "sadik0x01" (Orbitron)
- Desktop: horizontal menu | Mobile: hamburger with slide-in
- Theme toggle: sun/moon icon, 0.3s transitions

### Hero Section
- **Profile:** 150px circular, 5px purple border, pulse animation (scale 0.95-1.05, 2s)
- **Name:** "Sadik Mahmud" H1 green glow + "@sadik0x01" muted subtitle
- **Role:** Typing animation "Security Researcher, Penetration Tester, Bug Bounty Hunter"
- **Background:** particles.js green particles on dark canvas
- **CTA:** "View Resume" button (not download), green secondary style

### About Section
- Two columns (bio left, info card right) - stacks mobile
- Info card: lighter bg, rounded-lg, p-8
- Fields: Email, Location (Dhaka, Bangladesh), Languages (English, Bangla, Hindi, Urdu), Specialization

### Skills Section
- 6 skills, 2-column grid
- Progress bars: green fill on dark track, scroll-reveal animation, % labels
- Skills: Web App (90%), API (80%), Bash (40%), Mobile (75%), Smart Contract (25%), JS (85%)

### Achievements Section
- Vertical timeline, alternating cards desktop, stacked mobile
- Cards: darker bg, green left border (4px), icon + title + description
- All link to proof pages, underline hover
- Include: Google, Facebook, Microsoft, Adobe, Sony recognitions

### Certifications Section
- Placeholder: "Certifications Coming Soon..." centered
- Card with dashed border, muted text
- Subtext: "Professional certifications... OSCP, CEH, etc."

### Writeups Section
- Title + "Visit My Medium Blog" link (external icon)
- Subtext: "Read my latest security writeups..."
- CTA: "Read Articles" button → https://sadik0x01.medium.com/

### Contact Section
- Title: "Get In Touch" + "Don't Be Shy — Say Hi! 👋"
- Single column form: Name, Email, Message (textarea)
- Submit: green primary, "Send Message" + arrow icon
- Posts to sadikm0x01@gmail.com (setup required)
- Social grid: 8 icons (Twitter/X, LinkedIn, Facebook, GitHub, Discord, HTB, Medium, Email) - 4x2 desktop, 2x4 mobile

### Projects Navigation
- 5 tool cards, 2-3 col grid
- Cards: image/icon top, title, description, "Launch Tool" button
- Hover: lift effect (translateY -4px)

### Tool Pages - Search Interface
```html
<!-- Standard Search -->
<input class="w-full 2px-accent-border transparent-dark focus:glow" 
       placeholder="Enter target domain...">
<button class="accent-fill hover:scale-105">Search</button>

<!-- GitHub Dual Search -->
<div>Repository Search + Gist Search (separate inputs)</div>
```

### Dork Button Grid
- 2-col desktop, 1-col mobile, gap-4
- Style: dark bg, 4px accent left border, full-width, left-aligned
- Prefix: 🔍 emoji
- Hover: lighten bg, subtle translate
- Action: opens new tab, replaces "example.com" with user input

### Recon Methodology Cards
- Categories: Subdomain Enum, Secret Discovery, Passive Recon, Active Scan, Vuln Assessment
- Card: icon header, scrollable tool list, "Active" badges
- Grid: 2-3 col responsive

## Animations

**Use Sparingly:**
- **Particles:** Homepage only (not all pages)
- **Page Load:** 3s intro - spider logo pulse + fade-in
- **Scroll Reveals:** Fade-up cards (aos.js), stagger 100ms
- **Hovers:** Button scale 1.05, card lift translateY -4px, 0.3s ease
- **Progress Bars:** Animate width on scroll
- **Typing Effect:** Hero subtitle only
- **Theme Toggle:** 0.3s color transitions
- **Matrix Rain:** Recon page only (canvas overlay, green chars)

## Accessibility

- **Default:** Dark mode
- **Toggle:** localStorage persistent, 0.3s transitions
- **Contrast:** WCAG AA - green (#00dc82) on dark (#0d1117) = 8.2:1
- **Focus:** 2px green outline on all interactive elements
- **Keyboard:** Full tab order, enter/space activation
- **Screen Readers:** Semantic HTML5, aria-labels on icon buttons
- **Forms:** Always visible labels (not placeholder-only)

## Assets

### Profile Photo
- Source: My Profile Photo.jpg
- Treatment: 150px circular, 5px purple border, drop shadow, pulse animation

### Icons
- Tool icons: Spider logo, magnifying glass, terminal (SVG/font-awesome)
- Company logos: Google, Facebook, Microsoft, Adobe, Sony (SVG, max 60px, grayscale + green tint hover)
- No large hero images on tool pages

### Backgrounds
- CSS-generated only: particles.js, matrix rain
- No image files for patterns

## Implementation Notes

**GitHub Pages:**
- CNAME: "sadik0x01.me"
- Base URL: sadik0x01.github.io
- Relative URLs only
- Hash-based routing (#/github-dorks)

**Email Form:**
- Setup: SendGrid or Replit Mail required
- Fallback: mailto link
- Success: Green toast + form reset

**Dork Management:**
- Source: Bug Bounty Dorks ALL.txt, github dorks all.txt, google dorks all.txt, shodan dorks all.txt
- Deduplicate entries
- Group by category (Exposed Files, SQL Errors, Login Pages, etc.)

**Resume:**
- Link to hosted PDF (Google Drive/GitHub)
- Opens in new tab (no auto-download)