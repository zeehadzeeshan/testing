import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { contactMessageSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = contactMessageSchema.parse(req.body);
      
      console.log("Contact form submission:", validatedData);
      
      res.json({ 
        success: true, 
        message: "Message received successfully! We'll get back to you soon." 
      });
    } catch (error: any) {
      res.status(400).json({ 
        success: false, 
        message: error.errors?.[0]?.message || "Invalid form data" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
