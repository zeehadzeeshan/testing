import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Search, ExternalLink, Globe } from "lucide-react";

export default function ShodanDorks() {
  const [target, setTarget] = useState("");

  const dorks = [
    { label: "MongoDB Exposed", query: 'port:27017 -authentication' },
    { label: "Elasticsearch Instances", query: 'port:9200 all:"elastic indices"' },
    { label: "Jenkins Dashboard", query: 'http.title:"Dashboard [Jenkins]"' },
    { label: "Docker Exposed", query: 'product:"Docker"' },
    { label: "Redis Servers", query: 'product:"Redis"' },
    { label: "MySQL Databases", query: 'port:3306 product:"MySQL"' },
    { label: "PostgreSQL", query: 'port:5432 PostgreSQL' },
    { label: "FTP Anonymous Login", query: '"220" "230 Login successful." port:21' },
    { label: "RDP Exposed", query: 'port:3389 product:"Microsoft Terminal Services"' },
    { label: "VNC Exposed", query: 'port:5900 product:"VNC"' },
    { label: "Memcached Servers", query: 'port:11211 product:"Memcached"' },
    { label: "Kibana Dashboards", query: 'kibana' },
    { label: "Grafana Dashboards", query: 'http.title:"Grafana"' },
    { label: "Apache Server Status", query: 'http.title:"Apache Status"' },
    { label: "phpMyAdmin", query: 'http.title:"phpMyAdmin"' },
    { label: "Kubernetes API", query: 'product:"Kubernetes"' },
    { label: "SSL Expired", query: 'ssl.cert.expired:true' },
    { label: "WebCams", query: 'Server: yawcam' },
    { label: "Printers", query: 'http.title:"Printer"' },
    { label: "IoT Devices", query: 'product:"IoT"' },
    { label: "Cisco Devices", query: 'product:"Cisco"' },
    { label: "Netgear Routers", query: 'product:"Netgear"' },
    { label: "SCADA Systems", query: 'SCADA' },
    { label: "Industrial Control", query: 'product:"Siemens"' },
    { label: "SSL by Organization", query: 'ssl:"target"' },
    { label: "HTTP by Title", query: 'http.title:"target"' },
    { label: "By ASN", query: 'asn:AS####' },
    { label: "By Country", query: 'country:"US"' },
    { label: "By City", query: 'city:"London"' },
    { label: "By Hostname", query: 'hostname:target.com' },
  ];

  const searchShodan = (query: string) => {
    const searchTarget = target.trim();
    let finalQuery = query;
    if (searchTarget) {
      finalQuery = query.replace(/target/g, searchTarget);
    }
    window.open(`https://www.shodan.io/search?query=${encodeURIComponent(finalQuery)}`, "_blank");
  };

  return (
    <div className="min-h-screen pt-24 pb-12" style={{ background: "linear-gradient(to bottom, hsl(var(--background)), #1a0000)" }}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <Globe className="h-16 w-16 mx-auto mb-4 text-red-500 animate-pulse-glow" />
          <h1 className="text-5xl font-merienda font-black mb-4 text-red-500" style={{ textShadow: "0 0 20px rgba(220, 67, 52, 0.7)" }}>
            Shodan Dorks
          </h1>
          <p className="text-xl text-muted-foreground font-mono">Find exposed services and devices on the internet</p>
        </div>

        <Card className="max-w-4xl mx-auto p-8 mb-8 border border-red-500/30">
          <label htmlFor="target" className="block text-sm font-mono text-foreground mb-2">
            Enter Target Organization, Domain, or IP
          </label>
          <div className="flex gap-4">
            <Input
              id="target"
              type="text"
              placeholder="org:target or target.com or 192.168.1.1"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              className="flex-1 font-mono border-red-500/50 focus:border-red-500"
              data-testid="input-target"
            />
          </div>
        </Card>

        <div className="grid md:grid-cols-2 gap-4 max-w-6xl mx-auto">
          {dorks.map((dork, index) => (
            <Button
              key={index}
              variant="outline"
              className="justify-start gap-3 h-auto py-3 px-4 text-left hover-elevate active-elevate-2 border-red-500/30"
              onClick={() => searchShodan(dork.query)}
              data-testid={`button-dork-${index}`}
            >
              <Search className="h-4 w-4 flex-shrink-0 text-red-500" />
              <span className="font-mono text-sm flex-1">{dork.label}</span>
              <ExternalLink className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}
