import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Search, ExternalLink, Bug } from "lucide-react";

export default function BugBountyDorks() {
  const [domain, setDomain] = useState("");

  const dorks = [
    { label: "Bug Bounty Program", query: 'site:example.com inurl:bug inurl:bounty' },
    { label: "Security Bounty", query: 'site:example.com inurl:security intext:bounty' },
    { label: "Responsible Disclosure", query: 'site:example.com inurl:responsible-disclosure' },
    { label: "Security.txt", query: 'site:example.com inurl:/.well-known/security' },
    { label: "Vulnerability Disclosure", query: 'site:example.com intext:vulnerability disclosure program' },
    { label: "Security Rewards", query: 'site:example.com intext:security rewards' },
    { label: "Bug Bounty Payout", query: 'site:example.com intext:bug bounty payout' },
    { label: "Powered by HackerOne", query: '"powered by hackerone" "submit vulnerability report"' },
    { label: "Powered by Bugcrowd", query: '"powered by bugcrowd" -site:bugcrowd.com' },
    { label: "Hall of Fame", query: 'responsible disclosure hall of fame' },
    { label: "White Hat Program", query: 'white hat program' },
    { label: "Swag Program", query: 'inurl:/responsible-disclosure/ swag' },
    { label: "Security Seriously", query: 'intext:"we take security very seriously"' },
    { label: "Report Vulnerability", query: '"Report a Vulnerability"' },
    { label: "Bug Bounty with $", query: '"bug bounty program" "$"' },
    { label: "Bug Bounty with Bitcoin", query: '"bug bounty program" "₿"' },
    { label: "Security Report Reward", query: "inurl:'vulnerability-disclosure-policy' reward" },
    { label: "Monetary Compensation", query: '"responsible disclosure" intext:"you may be eligible for monetary compensation"' },
    { label: "University Programs", query: '"responsible disclosure" university' },
    { label: "Government Programs", query: 'allintitle: restricted filetype:doc site:gov' },
    { label: "Bug Bounty Europe", query: 'responsible disclosure europe' },
    { label: "Submit Vulnerability", query: '"submit vulnerability report"' },
    { label: "Security Policy", query: '"vulnerability reporting policy"' },
    { label: "Security Researchers", query: 'inurl:"/security-researchers"' },
    { label: "HackerOne Programs", query: 'site:hackerone.com "accepts submissions"' },
    { label: "Bugcrowd Programs", query: 'site:bugcrowd.com "open" -"closed"' },
    { label: "Intigriti Programs", query: 'site:intigriti.com "open"' },
    { label: "YesWeHack Programs", query: 'site:yeswehack.com "open"' },
    { label: "OpenBugBounty", query: 'site:openbugbounty.org' },
    { label: "BountyFactory", query: 'site:bountyfactory.io' },
  ];

  const searchGoogle = (query: string) => {
    const targetDomain = domain.trim() || "example.com";
    const finalQuery = query.replace(/example\.com/g, targetDomain);
    window.open(`https://www.google.com/search?q=${encodeURIComponent(finalQuery)}`, "_blank");
  };

  return (
    <div className="min-h-screen pt-24 pb-12" style={{ background: "linear-gradient(to bottom, hsl(var(--background)), #1a001a)" }}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <Bug className="h-16 w-16 mx-auto mb-4 text-pink-500 animate-pulse-glow" />
          <h1 className="text-5xl font-orbitron font-black mb-4 text-pink-500" style={{ textShadow: "0 0 20px rgba(255, 62, 136, 0.7)" }}>
            Bug Bounty Dorks
          </h1>
          <p className="text-xl text-muted-foreground font-mono">Discover unique bug bounty platforms and programs</p>
        </div>

        <Card className="max-w-4xl mx-auto p-8 mb-8 border border-pink-500/30">
          <label htmlFor="domain" className="block text-sm font-mono text-foreground mb-2">
            Enter Target Domain
          </label>
          <div className="flex gap-4">
            <Input
              id="domain"
              type="text"
              placeholder="example.com"
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              className="flex-1 font-mono border-pink-500/50 focus:border-pink-500"
              data-testid="input-domain"
            />
          </div>
        </Card>

        <div className="grid md:grid-cols-2 gap-4 max-w-6xl mx-auto">
          {dorks.map((dork, index) => (
            <Button
              key={index}
              variant="outline"
              className="justify-start gap-3 h-auto py-3 px-4 text-left hover-elevate active-elevate-2 border-pink-500/30"
              onClick={() => searchGoogle(dork.query)}
              data-testid={`button-dork-${index}`}
            >
              <Search className="h-4 w-4 flex-shrink-0 text-pink-500" />
              <span className="font-mono text-sm flex-1">{dork.label}</span>
              <ExternalLink className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}
