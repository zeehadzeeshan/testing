import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Shield, Search, Database, Lock, Globe, Terminal } from "lucide-react";

export default function ReconMethodology() {
  const [domain, setDomain] = useState("");

  const categories = [
    {
      title: "Subdomain Enumeration",
      icon: <Globe className="h-6 w-6" />,
      color: "text-primary",
      tools: [
        { name: "Sublist3r", url: "https://github.com/aboul3la/Sublist3r" },
        { name: "Amass", url: "https://github.com/OWASP/Amass" },
        { name: "Assetfinder", url: "https://github.com/tomnomnom/assetfinder" },
        { name: "Subfinder", url: "https://github.com/projectdiscovery/subfinder" },
        { name: "Crt.sh", url: "https://crt.sh/?q=example.com", replaceDomain: true },
        { name: "VirusTotal", url: "https://www.virustotal.com/gui/domain/example.com/relations", replaceDomain: true },
      ],
    },
    {
      title: "Port Scanning",
      icon: <Terminal className="h-6 w-6" />,
      color: "text-primary",
      tools: [
        { name: "Nmap", url: "https://nmap.org/" },
        { name: "Masscan", url: "https://github.com/robertdavidgraham/masscan" },
        { name: "RustScan", url: "https://github.com/RustScan/RustScan" },
        { name: "Shodan", url: "https://www.shodan.io/search?query=hostname:example.com", replaceDomain: true },
      ],
    },
    {
      title: "Secret Discovery",
      icon: <Lock className="h-6 w-6" />,
      color: "text-primary",
      tools: [
        { name: "TruffleHog", url: "https://github.com/trufflesecurity/trufflehog" },
        { name: "GitLeaks", url: "https://github.com/gitleaks/gitleaks" },
        { name: "GitRob", url: "https://github.com/michenriksen/gitrob" },
        { name: "GitHub Search", url: 'https://github.com/search?q=example.com+password&type=code', replaceDomain: true },
      ],
    },
    {
      title: "Directory Bruteforcing",
      icon: <Search className="h-6 w-6" />,
      color: "text-primary",
      tools: [
        { name: "Gobuster", url: "https://github.com/OJ/gobuster" },
        { name: "Dirsearch", url: "https://github.com/maurosoria/dirsearch" },
        { name: "Ffuf", url: "https://github.com/ffuf/ffuf" },
        { name: "Feroxbuster", url: "https://github.com/epi052/feroxbuster" },
      ],
    },
    {
      title: "Passive Reconnaissance",
      icon: <Database className="h-6 w-6" />,
      color: "text-primary",
      tools: [
        { name: "Wayback Machine", url: "https://web.archive.org/web/*/example.com", replaceDomain: true },
        { name: "URLScan", url: "https://urlscan.io/search/#example.com", replaceDomain: true },
        { name: "SecurityTrails", url: "https://securitytrails.com/domain/example.com/history/a", replaceDomain: true },
        { name: "Censys", url: "https://search.censys.io/search?q=example.com", replaceDomain: true },
        { name: "BGP Toolkit", url: "https://bgp.he.net/dns/example.com", replaceDomain: true },
      ],
    },
    {
      title: "Vulnerability Assessment",
      icon: <Shield className="h-6 w-6" />,
      color: "text-primary",
      tools: [
        { name: "Nuclei", url: "https://github.com/projectdiscovery/nuclei" },
        { name: "Nikto", url: "https://github.com/sullo/nikto" },
        { name: "OWASP ZAP", url: "https://www.zaproxy.org/" },
        { name: "Burp Suite", url: "https://portswigger.net/burp" },
        { name: "SQLMap", url: "https://sqlmap.org/" },
      ],
    },
  ];

  const openTool = (url: string, replaceDomain: boolean = false) => {
    let finalUrl = url;
    if (replaceDomain && domain.trim()) {
      finalUrl = url.replace(/example\.com/g, domain.trim());
    }
    window.open(finalUrl, "_blank");
  };

  return (
    <div className="min-h-screen pt-24 pb-12" style={{ background: "linear-gradient(to bottom, hsl(var(--background)), hsl(var(--card)))" }}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <Shield className="h-16 w-16 mx-auto mb-4 text-primary animate-pulse-glow" />
          <h1 className="text-5xl font-orbitron font-black mb-4 text-primary" style={{ textShadow: "0 0 20px rgba(0, 220, 130, 0.5)" }}>
            Recon Methodology
          </h1>
          <p className="text-xl text-muted-foreground font-mono">Comprehensive reconnaissance workflow and techniques</p>
        </div>

        <Card className="max-w-4xl mx-auto p-8 mb-8">
          <label htmlFor="domain" className="block text-sm font-mono text-foreground mb-2">
            Enter Target Domain
          </label>
          <Input
            id="domain"
            type="text"
            placeholder="example.com"
            value={domain}
            onChange={(e) => setDomain(e.target.value)}
            className="font-mono"
            data-testid="input-domain"
          />
        </Card>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
          {categories.map((category, categoryIndex) => (
            <Card key={categoryIndex} className="p-6 hover-elevate">
              <div className="flex items-center gap-3 mb-4">
                <div className={category.color}>{category.icon}</div>
                <h2 className="text-xl font-orbitron font-bold text-foreground">{category.title}</h2>
              </div>
              <div className="space-y-2">
                {category.tools.map((tool, toolIndex) => (
                  <Button
                    key={toolIndex}
                    variant="outline"
                    size="sm"
                    className="w-full justify-between group hover-elevate active-elevate-2"
                    onClick={() => openTool(tool.url, tool.replaceDomain)}
                    data-testid={`button-tool-${categoryIndex}-${toolIndex}`}
                  >
                    <span className="font-mono text-sm">{tool.name}</span>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="text-xs">Active</Badge>
                      <ExternalLink className="h-3 w-3 text-muted-foreground group-hover:text-primary" />
                    </div>
                  </Button>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
