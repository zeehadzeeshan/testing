import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Search, ExternalLink } from "lucide-react";

export default function GoogleDorks() {
  const [domain, setDomain] = useState("");

  const dorks = [
    { label: "Directory listing vulnerabilities", query: "site:example.com intitle:index.of" },
    { label: "Exposed Configuration files", query: "site:example.com ext:xml | ext:conf | ext:cnf | ext:reg | ext:inf | ext:rdp | ext:cfg | ext:txt | ext:ora | ext:ini" },
    { label: "Exposed Database files", query: "site:example.com ext:sql | ext:dbf | ext:mdb" },
    { label: "Exposed Log files", query: "site:example.com ext:log" },
    { label: "WordPress", query: "site:example.com inurl:wp- | inurl:wp-content | inurl:plugins | inurl:uploads | inurl:themes | inurl:download" },
    { label: "Backup and old files", query: "site:example.com ext:bkf | ext:bkp | ext:bak | ext:old | ext:backup" },
    { label: "Login Pages", query: "site:example.com inurl:login" },
    { label: "SQL Errors", query: 'site:example.com intext:"sql syntax near" | intext:"syntax error has occurred" | intext:"incorrect syntax near" | intext:"unexpected end of SQL command" | intext:"Warning: mysql_connect()" | intext:"Warning: mysql_query()" | intext:"Warning: pg_connect()"' },
    { label: "Publicly Exposed Documents", query: "site:example.com ext:doc | ext:docx | ext:odt | ext:pdf | ext:rtf | ext:sxw | ext:psw | ext:ppt | ext:pptx | ext:pps | ext:csv" },
    { label: "phpinfo()", query: 'site:example.com ext:php intitle:phpinfo "published by the PHP Group"' },
    { label: "Finding Backdoors", query: "site:example.com inurl:shell | inurl:backdoor | inurl:wso | inurl:cmd | shadow | passwd | boot.ini | inurl:backdoor" },
    { label: "Install / Setup files", query: "site:example.com inurl:readme | inurl:license | inurl:install | inurl:setup | inurl:config" },
    { label: "Open Redirects", query: "site:example.com inurl:redir | inurl:url | inurl:redirect | inurl:return | inurl:src=http | inurl:r=http" },
    { label: "Apache STRUTS RCE", query: "site:example.com ext:action | ext:struts | ext:do" },
    { label: "Find Pastebin entries", query: "site:pastebin.com example.com" },
    { label: "API Docs", query: "inurl:apidocs | inurl:api-docs | inurl:swagger | inurl:api-explorer site:example.com" },
    { label: "API Endpoints", query: "site:example.com inurl:api | site:*/rest | site:*/v1 | site:*/v2 | site:*/v3" },
    { label: "3rd Party Exposure", query: "site:http://ideone.com | site:http://codebeautify.org | site:http://codeshare.io | site:http://codepen.io | site:http://repl.it | site:http://justpaste.it | site:http://pastebin.com | site:http://jsfiddle.net | site:http://trello.com | site:*.atlassian.net | site:bitbucket.org example.com" },
    { label: "GitLab", query: "inurl:gitlab example.com" },
    { label: ".git folder", query: "inurl:example.com /.git" },
    { label: "Employees on LinkedIn", query: "site:linkedin.com employees example.com" },
    { label: ".htaccess sensitive files", query: "site:example.com.com inurl:/phpinfo.php | inurl:.htaccess" },
    { label: "JFrog Artifactory", query: 'site:jfrog.io "example.com"' },
    { label: "Find Subdomains", query: "site:*.example.com" },
    { label: "Find Sub-Subdomains", query: "site:*.*.example.com" },
    { label: "Find WordPress #2", query: "site:example.com inurl:wp-content | inurl:wp-includes" },
    { label: "Apache Server Status", query: "site:*/server-status apache" },
    { label: "Search in Bitbucket and Atlassian", query: "site:atlassian.net | site:bitbucket.org example.com" },
    { label: "Search in Stackoverflow", query: "site:stackoverflow.com example.com" },
    { label: "Digital Ocean Spaces", query: "site:digitaloceanspaces.com example.com" },
    { label: "Firebase", query: 'site:firebaseio.com "example.com"' },
    { label: "s3 Bucket", query: "site:.s3.amazonaws.com example.com" },
    { label: "Google APIs", query: 'site:googleapis.com "example.com"' },
    { label: "Google drive", query: 'site:drive.google.com "example.com"' },
    { label: "Finding exposed cloud credentials", query: 'site:example.com (intext:"aws_access_key_id" OR intext:"aws_secret_access_key") (filetype:json OR filetype:yaml)' },
    { label: "Azure", query: 'site:dev.azure.com "example.com"' },
    { label: "OneDrive", query: 'site:onedrive.live.com "example.com"' },
    { label: "DropBox", query: 'site:dropbox.com/s "example.com"' },
    { label: "Google Docs", query: 'site:docs.google.com inurl:"/d/" "example.com"' },
  ];

  const searchGoogle = (query: string) => {
    const targetDomain = domain.trim() || "example.com";
    const finalQuery = query.replace(/example\.com/g, targetDomain);
    window.open(`https://www.google.com/search?q=${encodeURIComponent(finalQuery)}`, "_blank");
  };

  return (
    <div className="min-h-screen pt-24 pb-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-orbitron font-black mb-4 text-primary" style={{ textShadow: "0 0 20px rgba(0, 220, 130, 0.5)" }}>
            Google Dorks
          </h1>
          <p className="text-xl text-muted-foreground font-mono">Advanced Google search queries for security research</p>
        </div>

        <Card className="max-w-4xl mx-auto p-8 mb-8">
          <label htmlFor="domain" className="block text-sm font-mono text-foreground mb-2">
            Enter Target Domain
          </label>
          <div className="flex gap-4">
            <Input
              id="domain"
              type="text"
              placeholder="example.com"
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              className="flex-1 font-mono"
              data-testid="input-domain"
            />
          </div>
        </Card>

        <div className="grid md:grid-cols-2 gap-4 max-w-6xl mx-auto">
          {dorks.map((dork, index) => (
            <Button
              key={index}
              variant="outline"
              className="justify-start gap-3 h-auto py-3 px-4 text-left hover-elevate active-elevate-2"
              onClick={() => searchGoogle(dork.query)}
              data-testid={`button-dork-${index}`}
            >
              <Search className="h-4 w-4 flex-shrink-0 text-primary" />
              <span className="font-mono text-sm flex-1">{dork.label}</span>
              <ExternalLink className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}
