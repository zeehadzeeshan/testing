import { useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Github,
  Twitter,
  Linkedin,
  Facebook,
  MessageCircle,
  FileText,
  Mail,
  ExternalLink,
  Search,
  Shield,
  Bug,
  Globe,
} from "lucide-react";
import { Link } from "wouter";
import { contactMessageSchema, type ContactMessage } from "@shared/schema";

export default function Home() {
  const particlesRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const form = useForm<ContactMessage>({
    resolver: zodResolver(contactMessageSchema),
    defaultValues: {
      name: "",
      email: "",
      message: "",
    },
  });

  const contactMutation = useMutation({
    mutationFn: async (data: ContactMessage) => {
      const response = await apiRequest("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Success!",
        description: data.message,
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to send message. Please try again.",
      });
    },
  });

  const onSubmit = (data: ContactMessage) => {
    contactMutation.mutate(data);
  };

  useEffect(() => {
    if (particlesRef.current && (window as any).particlesJS) {
      (window as any).particlesJS("particles-js", {
        particles: {
          number: { value: 80, density: { enable: true, value_area: 800 } },
          color: { value: "#00dc82" },
          shape: {
            type: "circle",
            stroke: { width: 0, color: "#000000" },
          },
          opacity: {
            value: 0.5,
            random: false,
            anim: { enable: false, speed: 1, opacity_min: 0.1, sync: false },
          },
          size: {
            value: 3,
            random: true,
            anim: { enable: false, speed: 40, size_min: 0.1, sync: false },
          },
          line_linked: {
            enable: true,
            distance: 150,
            color: "#00dc82",
            opacity: 0.4,
            width: 1,
          },
          move: {
            enable: true,
            speed: 2,
            direction: "none",
            random: false,
            straight: false,
            out_mode: "out",
            bounce: false,
          },
        },
        interactivity: {
          detect_on: "canvas",
          events: {
            onhover: { enable: true, mode: "repulse" },
            onclick: { enable: true, mode: "push" },
            resize: true,
          },
        },
        retina_detect: true,
      });
    }
  }, []);

  const skills = [
    { name: "Web Application Pentesting", progress: 90 },
    { name: "API Pentesting", progress: 80 },
    { name: "Bash", progress: 40 },
    { name: "Mobile Pentesting", progress: 75 },
    { name: "Smart Contract Hacking", progress: 25 },
    { name: "Javascript", progress: 85 },
  ];

  const achievements = [
    {
      title: "Bug Reported & Awarded By Google",
      icon: <Shield className="h-6 w-6 text-primary" />,
      link: "#",
    },
    {
      title: "Google Honorable Mentions",
      icon: <Bug className="h-6 w-6 text-primary" />,
      link: "#",
    },
    {
      title: "Bug Reported & Awarded By Facebook",
      icon: <Search className="h-6 w-6 text-primary" />,
      link: "#",
    },
    {
      title: "Acknowledged by Microsoft",
      icon: <Globe className="h-6 w-6 text-primary" />,
      link: "#",
    },
    {
      title: "Adobe Hall of Fame",
      icon: <Shield className="h-6 w-6 text-primary" />,
      link: "#",
    },
    {
      title: "Received Swag From Sony",
      icon: <Bug className="h-6 w-6 text-primary" />,
      link: "#",
    },
  ];

  const tools = [
    {
      title: "Google Dorks",
      description: "Advanced Google search queries for security research",
      icon: <Search className="h-8 w-8" />,
      href: "/google-dorks",
      color: "text-primary",
    },
    {
      title: "GitHub Dorks",
      description: "Search GitHub repositories and Gists for sensitive data",
      icon: <Github className="h-8 w-8" />,
      href: "/github-dorks",
      color: "text-purple-500",
    },
    {
      title: "Shodan Dorks",
      description: "Find exposed services and devices on the internet",
      icon: <Globe className="h-8 w-8" />,
      href: "/shodan-dorks",
      color: "text-red-500",
    },
    {
      title: "Bug Bounty Dorks",
      description: "Discover unique bug bounty platforms and programs",
      icon: <Bug className="h-8 w-8" />,
      href: "/bug-bounty-dorks",
      color: "text-pink-500",
    },
    {
      title: "Recon Methodology",
      description: "Comprehensive reconnaissance workflow and techniques",
      icon: <Shield className="h-8 w-8" />,
      href: "/recon",
      color: "text-primary",
    },
  ];

  const socialLinks = [
    { icon: <Twitter className="h-5 w-5" />, href: "https://x.com/sadik0x01", label: "Twitter/X" },
    { icon: <Linkedin className="h-5 w-5" />, href: "https://www.linkedin.com/in/sadik0x01/", label: "LinkedIn" },
    { icon: <Facebook className="h-5 w-5" />, href: "https://www.facebook.com/sadik0x01", label: "Facebook" },
    { icon: <Github className="h-5 w-5" />, href: "https://github.com/sadik0x01", label: "GitHub" },
    { icon: <MessageCircle className="h-5 w-5" />, href: "https://discord.com/users/1033024826799030312", label: "Discord" },
    { icon: <Shield className="h-5 w-5" />, href: "https://app.hackthebox.com/profile/1314761", label: "HackTheBox" },
    { icon: <FileText className="h-5 w-5" />, href: "https://sadik0x01.medium.com/", label: "Medium" },
    { icon: <Mail className="h-5 w-5" />, href: "mailto:sadikm0x01@gmail.com", label: "Email" },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section with Particles */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
        <div ref={particlesRef} id="particles-js" className="absolute inset-0 z-0" />
        
        <div className="container mx-auto px-4 z-10 text-center">
          <div className="inline-block mb-8">
            <img
              src="/profile.jpg"
              alt="Sadik Mahmud"
              className="w-40 h-40 rounded-full border-4 border-purple-600 shadow-2xl shadow-purple-500/50 animate-pulse-glow mx-auto"
              data-testid="img-profile"
            />
          </div>
          
          <h1 className="text-5xl md:text-7xl font-orbitron font-black mb-4 text-primary animate-fade-in-up" style={{ textShadow: "0 0 20px rgba(0, 220, 130, 0.5)" }}>
            Sadik Mahmud
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground mb-2 font-mono">@sadik0x01</p>
          
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            <Badge variant="secondary" className="text-sm">Security Researcher</Badge>
            <Badge variant="secondary" className="text-sm">Bug Bounty Hunter</Badge>
            <Badge variant="secondary" className="text-sm">Penetration Tester</Badge>
          </div>

          <div className="flex justify-center gap-4 mb-8">
            <Button variant="outline" size="lg" asChild data-testid="button-view-resume">
              <a href="#" target="_blank" rel="noopener noreferrer" className="font-mono">
                View Resume <ExternalLink className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </div>

          <div className="flex justify-center gap-4 flex-wrap">
            {socialLinks.map((link, index) => (
              <Button
                key={index}
                variant="ghost"
                size="icon"
                asChild
                className="hover-elevate active-elevate-2"
                data-testid={`button-social-${link.label.toLowerCase().replace(/\//g, '-')}`}
              >
                <a href={link.href} target="_blank" rel="noopener noreferrer" aria-label={link.label}>
                  {link.icon}
                </a>
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-card/50" id="about">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-orbitron font-bold text-center mb-12 text-primary">About Me</h2>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            <Card className="p-8 hover-elevate">
              <p className="text-lg leading-relaxed text-foreground">
                As an ethical hacker and dedicated bug bounty hunter, I specialize in uncovering and addressing critical security vulnerabilities across Web applications, Mobile apps, and APIs. My approach involves rigorous Vulnerability Assessments and Penetration Testing, aimed at strengthening an organization's digital defenses.
              </p>
              <p className="text-lg leading-relaxed text-foreground mt-4">
                Driven by a profound passion for cybersecurity, I actively work to find and fix flaws, thereby enhancing overall digital safety and fostering a more secure online ecosystem.
              </p>
            </Card>

            <Card className="p-8 hover-elevate">
              <div className="space-y-4">
                <div>
                  <h3 className="font-mono text-sm text-muted-foreground mb-1">Email</h3>
                  <p className="text-foreground">sadikm0x01@gmail.com</p>
                </div>
                <div>
                  <h3 className="font-mono text-sm text-muted-foreground mb-1">Location</h3>
                  <p className="text-foreground">Dhaka, Bangladesh</p>
                </div>
                <div>
                  <h3 className="font-mono text-sm text-muted-foreground mb-1">Specialization</h3>
                  <p className="text-foreground">Bug Bounty Hunter, Security Researcher, Web Pentester</p>
                </div>
                <div>
                  <h3 className="font-mono text-sm text-muted-foreground mb-1">Languages</h3>
                  <p className="text-foreground">English, Bangla, Hindi, Urdu</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="py-20" id="skills">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-orbitron font-bold text-center mb-12 text-primary">Skills</h2>
          
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {skills.map((skill) => (
              <div key={skill.name} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-mono text-sm text-foreground">{skill.name}</span>
                  <span className="font-mono text-sm text-primary font-bold">{skill.progress}%</span>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all duration-1000 ease-out"
                    style={{ width: `${skill.progress}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <section className="py-20 bg-card/50" id="achievements">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-orbitron font-bold text-center mb-12 text-primary">Achievements</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {achievements.map((achievement, index) => (
              <Card
                key={index}
                className="p-6 hover-elevate active-elevate-2 cursor-pointer"
                data-testid={`card-achievement-${index}`}
              >
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">{achievement.icon}</div>
                  <div>
                    <h3 className="font-mono text-sm text-foreground">{achievement.title}</h3>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section className="py-20" id="certifications">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-orbitron font-bold text-center mb-12 text-primary">Certifications</h2>
          
          <Card className="max-w-2xl mx-auto p-12 text-center border-dashed">
            <h3 className="text-2xl font-bold text-muted-foreground mb-4">Certifications Coming Soon...</h3>
            <p className="text-muted-foreground">
              Professional certifications and credentials will be displayed here. Stay tuned for updates on OSCP, CEH, and other security certifications.
            </p>
          </Card>
        </div>
      </section>

      {/* Tools/Projects Section */}
      <section className="py-20 bg-card/50" id="projects">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-orbitron font-bold text-center mb-12 text-primary">Security Tools</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {tools.map((tool, index) => (
              <Link key={index} href={tool.href}>
                <Card className="p-6 hover-elevate active-elevate-2 cursor-pointer h-full transition-transform hover:-translate-y-1" data-testid={`card-tool-${tool.title.toLowerCase().replace(/\s+/g, '-')}`}>
                  <div className={`mb-4 ${tool.color}`}>{tool.icon}</div>
                  <h3 className="text-xl font-orbitron font-bold mb-2 text-foreground">{tool.title}</h3>
                  <p className="text-muted-foreground text-sm">{tool.description}</p>
                  <Button variant="ghost" className="mt-4 w-full" size="sm">
                    Launch Tool <ExternalLink className="ml-2 h-4 w-4" />
                  </Button>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Writeups Section */}
      <section className="py-20" id="writeups">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-orbitron font-bold text-center mb-12 text-primary">Writeups</h2>
          
          <Card className="max-w-2xl mx-auto p-8 text-center">
            <FileText className="h-16 w-16 mx-auto mb-4 text-primary" />
            <h3 className="text-2xl font-bold mb-4 text-foreground">Visit My Medium Blog</h3>
            <p className="text-muted-foreground mb-6">
              Read my latest security writeups and research articles
            </p>
            <Button asChild size="lg" data-testid="button-read-articles">
              <a href="https://sadik0x01.medium.com/" target="_blank" rel="noopener noreferrer" className="font-mono">
                Read Articles <ExternalLink className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </Card>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-card/50" id="contact">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-orbitron font-bold mb-4 text-primary">Get In Touch</h2>
            <p className="text-xl text-muted-foreground">Don't Be Shy — Say Hi!</p>
          </div>
          
          <Card className="max-w-2xl mx-auto p-8">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6" data-testid="form-contact">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono">Name</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="text"
                          placeholder="Your name"
                          className="font-mono"
                          data-testid="input-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono">Email</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="email"
                          placeholder="your.email@example.com"
                          className="font-mono"
                          data-testid="input-email"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono">Message</FormLabel>
                      <FormControl>
                        <Textarea
                          {...field}
                          placeholder="Your message..."
                          rows={6}
                          className="font-mono"
                          data-testid="input-message"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full font-mono" 
                  size="lg" 
                  data-testid="button-send-message"
                  disabled={contactMutation.isPending}
                >
                  {contactMutation.isPending ? "Sending..." : "Send Message"}
                </Button>
              </form>
            </Form>
          </Card>

          <div className="mt-12 text-center">
            <h3 className="text-2xl font-orbitron font-bold mb-6 text-foreground">Connect With Me</h3>
            <div className="flex justify-center gap-4 flex-wrap">
              {socialLinks.map((link, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="icon"
                  asChild
                  className="hover-elevate active-elevate-2"
                >
                  <a href={link.href} target="_blank" rel="noopener noreferrer" aria-label={link.label}>
                    {link.icon}
                  </a>
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-border">
        <div className="container mx-auto px-4 text-center">
          <p className="text-muted-foreground font-mono text-sm">
            © 2024 Sadik Mahmud (@sadik0x01) - Security Researcher
          </p>
        </div>
      </footer>
    </div>
  );
}
