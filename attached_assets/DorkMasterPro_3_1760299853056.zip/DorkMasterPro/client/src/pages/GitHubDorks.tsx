import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Search, ExternalLink, Github } from "lucide-react";

export default function GitHubDorks() {
  const [repoTarget, setRepoTarget] = useState("");
  const [gistTarget, setGistTarget] = useState("");

  const repoDorks = [
    { label: "SQL Dumps", query: '"#mysql dump" filetype:sql' },
    { label: "Password Files", query: 'filename:passwords.txt' },
    { label: "AWS Keys", query: '"aws_access_key_id"' },
    { label: "Private Keys", query: 'filename:id_rsa OR filename:id_dsa' },
    { label: "Config Files", query: 'filename:.env DB_PASSWORD' },
    { label: "API Keys", query: 'filename:.env API_KEY' },
    { label: "Database Connection Strings", query: 'filename:web.config connectionString' },
    { label: "Secret Keys", query: 'SECRET_KEY OR PRIVATE_KEY' },
    { label: "FTP Credentials", query: 'filename:filezilla.xml Pass' },
    { label: "Email Passwords", query: 'filename:eml password' },
    { label: "Token Leaks", query: 'access_token OR refresh_token' },
    { label: "OAuth Tokens", query: 'oauth_token' },
    { label: "Database Dumps", query: '"Dumping data for table"' },
    { label: "Index of /", query: 'intitle:"index of"' },
    { label: ".htpasswd files", query: 'filename:.htpasswd' },
    { label: "Git Config", query: 'filename:.git-credentials' },
    { label: "NPM Publish Token", query: '"_authToken"' },
    { label: "PyPI Token", query: 'filename:.pypirc' },
    { label: "Docker Auth", query: 'filename:config.json auth' },
    { label: "Kubernetes Secrets", query: 'kind: Secret' },
  ];

  const gistDorks = [
    { label: "Passwords in Gists", query: 'password' },
    { label: "AWS Credentials", query: 'aws_access_key_id aws_secret_access_key' },
    { label: "API Keys", query: 'api_key OR apikey' },
    { label: "Private Keys", query: 'BEGIN RSA PRIVATE KEY' },
    { label: "Database Strings", query: 'jdbc:mysql OR jdbc:postgresql' },
    { label: "SSH Config", query: 'Host * User git' },
    { label: "Email Lists", query: '@gmail.com OR @yahoo.com' },
    { label: "OAuth Secrets", query: 'client_secret' },
    { label: "Stripe Keys", query: 'sk_live OR pk_live' },
    { label: "Twilio Keys", query: 'AC[a-z0-9]{32}' },
    { label: "Slack Tokens", query: 'xoxb-' },
    { label: "GitHub Tokens", query: 'ghp_ OR gho_' },
    { label: "JWT Tokens", query: 'eyJ[A-Za-z0-9-_=]+\\.' },
    { label: "Firebase URLs", query: 'firebaseio.com' },
    { label: "SendGrid Keys", query: 'SG\\.' },
  ];

  const searchGitHub = (query: string, target: string) => {
    const searchTarget = target.trim() || "target";
    const finalQuery = `${query} ${searchTarget}`;
    window.open(`https://github.com/search?q=${encodeURIComponent(finalQuery)}&type=code`, "_blank");
  };

  const searchGist = (query: string, target: string) => {
    const searchTarget = target.trim() || "target";
    const finalQuery = `${query} ${searchTarget}`;
    window.open(`https://gist.github.com/search?q=${encodeURIComponent(finalQuery)}`, "_blank");
  };

  return (
    <div className="min-h-screen pt-24 pb-12" style={{ background: "linear-gradient(to bottom, hsl(var(--background)), hsl(var(--card)))" }}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <Github className="h-16 w-16 mx-auto mb-4 text-purple-500 animate-pulse-glow" />
          <h1 className="text-5xl font-orbitron font-black mb-4 text-purple-500" style={{ textShadow: "0 0 20px rgba(138, 9, 100, 0.5)" }}>
            GitHub Dorks
          </h1>
          <p className="text-xl text-muted-foreground font-mono">Search GitHub repositories and Gists for sensitive data</p>
        </div>

        {/* GitHub Repository Search */}
        <Card className="max-w-6xl mx-auto p-8 mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Github className="h-6 w-6 text-purple-500" />
            <h2 className="text-2xl font-orbitron font-bold text-foreground">GitHub Repository Search</h2>
          </div>
          <label htmlFor="repo-target" className="block text-sm font-mono text-foreground mb-2">
            Enter Organization or Target
          </label>
          <div className="flex gap-4 mb-6">
            <Input
              id="repo-target"
              type="text"
              placeholder="org:target or target.com"
              value={repoTarget}
              onChange={(e) => setRepoTarget(e.target.value)}
              className="flex-1 font-mono"
              data-testid="input-repo-target"
            />
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {repoDorks.map((dork, index) => (
              <Button
                key={index}
                variant="outline"
                className="justify-start gap-3 h-auto py-3 px-4 text-left hover-elevate active-elevate-2"
                onClick={() => searchGitHub(dork.query, repoTarget)}
                data-testid={`button-repo-dork-${index}`}
              >
                <Search className="h-4 w-4 flex-shrink-0 text-purple-500" />
                <span className="font-mono text-sm flex-1">{dork.label}</span>
                <ExternalLink className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
              </Button>
            ))}
          </div>
        </Card>

        {/* GitHub Gist Search */}
        <Card className="max-w-6xl mx-auto p-8">
          <div className="flex items-center gap-3 mb-4">
            <Search className="h-6 w-6 text-lime-500" />
            <h2 className="text-2xl font-orbitron font-bold text-foreground">GitHub Gist Search</h2>
          </div>
          <label htmlFor="gist-target" className="block text-sm font-mono text-foreground mb-2">
            Enter Target Domain or Keyword
          </label>
          <div className="flex gap-4 mb-6">
            <Input
              id="gist-target"
              type="text"
              placeholder="target.com or keyword"
              value={gistTarget}
              onChange={(e) => setGistTarget(e.target.value)}
              className="flex-1 font-mono"
              data-testid="input-gist-target"
            />
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {gistDorks.map((dork, index) => (
              <Button
                key={index}
                variant="outline"
                className="justify-start gap-3 h-auto py-3 px-4 text-left hover-elevate active-elevate-2"
                onClick={() => searchGist(dork.query, gistTarget)}
                data-testid={`button-gist-dork-${index}`}
              >
                <Search className="h-4 w-4 flex-shrink-0 text-lime-500" />
                <span className="font-mono text-sm flex-1">{dork.label}</span>
                <ExternalLink className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
              </Button>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
