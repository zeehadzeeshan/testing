# Design Guidelines: Cybersecurity Portfolio & Dork Search Platform

## Design Approach: Reference-Based with Cybersecurity Identity

**Primary References:**
- **HackTheBox Platform**: Dark interface, terminal aesthetics, neon green accents
- **GitHub Dark Theme**: Clean code presentation, professional dark UI
- **Linear**: Modern typography, sharp contrast, minimalist approach
- **Terminal/Matrix Aesthetic**: Hacker culture visual language

**Justification**: This is a specialized cybersecurity portfolio requiring strong visual identity that communicates technical expertise while maintaining professional credibility. The design must balance hacker culture aesthetics with portfolio professionalism.

---

## Core Design Elements

### A. Color Palette

**Main Portfolio (Dark Cybersecurity Theme):**
- **Background**: 
  - Primary: 10 15% 8% (Deep charcoal)
  - Secondary: 10 12% 12% (Card backgrounds)
- **Primary Brand**: 
  - Neon Green: 145 85% 55% (Matrix green for accents)
  - Bright Green: 145 75% 65% (Hover states)
- **Text Colors**:
  - Primary: 0 0% 98% (Off-white)
  - Secondary: 145 20% 75% (Muted green-tinted gray)
  - Accent: 145 85% 55% (Links, highlights)
- **Status/Utility**:
  - Success: 145 85% 55%
  - Warning: 45 95% 60%
  - Error: 0 85% 60%

**Dork Search Tools (Varied Themes per Tool):**
- **GitHub Dorks**: Purple-focused (265 90% 65%) with dark slate background
- **Shodan Dorks**: Cyan-focused (190 85% 55%) with navy background  
- **Google Dorks**: Blue-focused (220 85% 60%) with deep blue background
- **Bug Bounty Dorks**: Red-focused (0 75% 60%) with charcoal background
- **Recon Methodology**: Orange-focused (30 85% 60%) with dark brown background

### B. Typography

**Fonts** (via Google Fonts):
- **Display/Headers**: 'Orbitron' - Bold geometric sans for cyber aesthetic (700, 900 weights)
- **Body/UI**: 'Inter' - Clean, readable sans-serif (400, 500, 600 weights)
- **Code/Terminal**: 'Fira Code' - Monospace for technical elements (400, 500, 700 weights)

**Scale**:
- Hero Headline: 4xl-6xl (clamp(2.5rem, 5vw, 4rem))
- Section Headers: 3xl-4xl 
- Subsection: xl-2xl
- Body: base-lg
- Small/Meta: sm-base
- Code snippets: sm monospace

### C. Layout System

**Spacing Primitives**: Tailwind units of 4, 8, 12, 16, 24, 32
- Component padding: p-8 to p-12
- Section spacing: py-16 to py-32
- Card spacing: p-6 to p-8
- Grid gaps: gap-8 to gap-12

**Container Strategy**:
- Max-width: 7xl (1280px) for main content
- Max-width: 6xl for text-heavy sections
- Full-width for hero sections with inner constraints

### D. Component Library

**Navigation**:
- Sticky header with blur backdrop (backdrop-blur-lg)
- Logo left, nav links center, social icons right
- Mobile: Hamburger menu with slide-in drawer
- Active state: Neon green underline animation

**Hero Section (Main Portfolio)**:
- Full viewport height (min-h-screen)
- Centered animated profile picture (300px circle with neon green glow pulse)
- Terminal-style typing animation for role/title
- Particle.js background with green particles
- Floating geometric shapes (subtle)

**Profile Image Treatment**:
- Circular frame with animated neon green border (rotating gradient)
- Hover: Scale 1.05 with increased glow
- Shadow: Multiple layered green glows for depth

**Cards/Sections**:
- Dark glass-morphism effect (bg-opacity-50 with blur)
- Border: 1px solid with green accent (border-l-4 border-green)
- Hover: Lift effect (translateY(-4px)) with green shadow
- Corner accents: Small green geometric shapes

**Buttons**:
- Primary: Solid green with black text, hover darkens
- Secondary: Outline green with transparent bg, hover fills
- Ghost: Text only with underline animation
- Terminal style: Monospace font with bracket decoration `[BUTTON]`

**Dork Search Components**:
- Search bar: Terminal-style input with green cursor animation
- Dork cards: Grid layout with category badges
- Click action: Opens new tab with animated pulse feedback
- Category filters: Pill-style buttons with active state
- Copy functionality: Icon button with success animation

**Contact Form**:
- Glass-morphism container
- Input fields: Dark with green focus border and glow
- Floating labels with smooth transition
- Submit button: Green with loading state animation
- Success message: Terminal-style popup

**Social Links**:
- Icon grid with brand colors on hover
- Circular icons with border on hover
- Smooth color transition animations
- Positioned in both header and footer

### E. Animations & Interactions

**Micro-interactions**:
- Button hover: Scale 1.02 with glow increase
- Card hover: Lift with shadow expansion
- Link hover: Underline slide-in from left
- Input focus: Border glow pulse (green)

**Page Transitions**:
- Fade in on scroll (intersection observer)
- Stagger children animations (0.1s delay each)
- Hero elements: Slide up with fade (stagger)

**Special Effects**:
- Cursor trail: Subtle green particle effect
- Code blocks: Syntax highlighting with green accents
- Terminal animations: Typing effect for headers
- Matrix rain: Optional background for dork pages (subtle)

**Performance**: Use CSS transforms and opacity only, minimize JavaScript animations

---

## Page-Specific Designs

### Main Portfolio Page

**Structure** (7 sections):
1. **Hero**: Full screen, animated profile, particle background, terminal greeting
2. **About**: Two-column (image left, bio right), skills grid below
3. **Specialization**: Icon cards in 3-column grid
4. **Achievements**: Timeline layout (commented placeholder)
5. **Certifications**: "Coming Soon" state with futuristic card design
6. **Writeups**: Featured Medium articles cards, "Read Articles" CTA
7. **Contact**: Split layout (form left, info + social right)

**Footer**: 
- Three columns: About, Quick Links, Connect
- All social links with icons
- Copyright with green accent line

### Dork Search Pages (Unique Designs Each)

**Common Elements**:
- Header with logo + back to portfolio link
- Search bar (prominent, top third of page)
- Category filters (horizontal scroll on mobile)
- Dork display grid (responsive 1-2-3 columns)
- Footer with attribution

**GitHub Dorks**:
- Code editor aesthetic
- Syntax-highlighted dork preview
- Repository-style layout

**Shodan Dorks**:
- Network diagram background (subtle)
- Terminal-focused interface
- IP/port visual indicators

**Google Dorks**:
- Search engine inspired layout
- Result-card style dorks
- Color-coded categories

**Bug Bounty Dorks**:
- Target/scope focused design
- Vulnerability category badges
- Platform integration hints

**Recon Methodology**:
- Workflow diagram background
- Step-by-step visual flow
- Tool integration callouts

---

## Images

**Profile Photo**: 
- Placement: Center of hero section, main portfolio
- Treatment: Circular, 300px diameter, animated green border glow
- Effect: Pulse animation on page load

**Hero Background**:
- Particle.js canvas (green particles on dark)
- Optional: Subtle circuit board pattern overlay

**Section Dividers**:
- Geometric green line patterns
- Glitch effect dividers between major sections

**Dork Page Backgrounds**:
- Each page: Unique subtle pattern (circuit, matrix, network, code)
- Opacity: 5-10% to maintain readability
- No large hero images on dork pages (focus on functionality)

---

## Accessibility & Performance

- High contrast: Green on dark exceeds WCAG AAA
- Focus indicators: Thick green outline (3px)
- Reduced motion: Respect prefers-reduced-motion
- Semantic HTML: Proper heading hierarchy
- Lazy load: Images and heavy components below fold
- Font loading: Swap strategy to prevent FOIT

---

## GitHub Pages Deployment

- Include CNAME file with: sadik0x01.me
- Custom 404 page with terminal theme
- robots.txt for SEO
- sitemap.xml generation
- Meta tags for social sharing (Open Graph)