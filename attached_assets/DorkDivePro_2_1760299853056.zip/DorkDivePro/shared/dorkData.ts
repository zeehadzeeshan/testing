import type { Dork, DorkCategory } from './schema';

// This will be populated from the backend after parsing the text files
export const dorkDatabases: Record<string, Dork[]> = {};

export function parseDorkFile(content: string, platform: 'github' | 'shodan' | 'google' | 'bugbounty' | 'recon'): Dork[] {
  const lines = content.split('\n').filter(line => line.trim());
  const dorks: Dork[] = [];
  
  lines.forEach((line, index) => {
    const trimmed = line.trim();
    if (!trimmed) return;
    
    dorks.push({
      id: `${platform}-${index}`,
      query: trimmed,
      category: extractCategory(trimmed, platform),
      platform
    });
  });
  
  return dorks;
}

function extractCategory(query: string, platform: string): string {
  // Extract category based on keywords in the query
  const lower = query.toLowerCase();
  
  if (platform === 'github') {
    if (lower.includes('api') || lower.includes('key')) return 'API Keys';
    if (lower.includes('password') || lower.includes('pwd')) return 'Passwords';
    if (lower.includes('config') || lower.includes('env')) return 'Configuration';
    if (lower.includes('db') || lower.includes('database')) return 'Database';
    if (lower.includes('token') || lower.includes('secret')) return 'Secrets';
    if (lower.includes('sql') || lower.includes('dump')) return 'SQL';
    return 'General';
  }
  
  if (platform === 'shodan') {
    if (lower.includes('camera') || lower.includes('webcam')) return 'Cameras';
    if (lower.includes('scada') || lower.includes('ics')) return 'Industrial';
    if (lower.includes('port:')) return 'Port Scanning';
    if (lower.includes('country:')) return 'Geolocation';
    if (lower.includes('http')) return 'Web Services';
    return 'IoT Devices';
  }
  
  if (platform === 'google') {
    if (lower.includes('inurl:admin') || lower.includes('intitle:admin')) return 'Admin Panels';
    if (lower.includes('filetype:')) return 'File Types';
    if (lower.includes('intext:password')) return 'Exposed Credentials';
    if (lower.includes('index of')) return 'Directory Listing';
    if (lower.includes('error') || lower.includes('warning')) return 'Error Messages';
    if (lower.includes('sql') || lower.includes('database')) return 'SQL Injection';
    return 'Information Disclosure';
  }
  
  if (platform === 'bugbounty') {
    if (lower.includes('responsible disclosure') || lower.includes('vulnerability disclosure')) return 'Disclosure Programs';
    if (lower.includes('bounty') || lower.includes('reward')) return 'Paid Programs';
    if (lower.includes('hall of fame') || lower.includes('acknowledgement')) return 'Recognition';
    if (lower.includes('swag') || lower.includes('hoodie')) return 'Swag Programs';
    if (lower.includes('security.txt') || lower.includes('.well-known')) return 'Security Policies';
    return 'Bug Bounty';
  }
  
  if (platform === 'recon') {
    if (lower.includes('subdomain') || lower.includes('dns')) return 'Subdomain Enumeration';
    if (lower.includes('port') || lower.includes('nmap')) return 'Port Scanning';
    if (lower.includes('screenshot') || lower.includes('visual')) return 'Visual Recon';
    if (lower.includes('wayback') || lower.includes('archive')) return 'Historical Data';
    if (lower.includes('tech') || lower.includes('wappalyzer')) return 'Technology Stack';
    return 'Reconnaissance';
  }
  
  return 'Uncategorized';
}

export function getCategories(dorks: Dork[]): DorkCategory[] {
  const categoryMap = new Map<string, number>();
  
  dorks.forEach(dork => {
    const count = categoryMap.get(dork.category) || 0;
    categoryMap.set(dork.category, count + 1);
  });
  
  return Array.from(categoryMap.entries())
    .map(([name, count]) => ({
      name,
      count,
      platform: dorks[0]?.platform || 'general'
    }))
    .sort((a, b) => b.count - a.count);
}
