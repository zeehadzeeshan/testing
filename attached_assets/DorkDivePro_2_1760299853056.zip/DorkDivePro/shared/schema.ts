import { z } from "zod";

// Portfolio Content Types
export interface SocialLink {
  platform: string;
  url: string;
  icon: string;
}

export interface Skill {
  name: string;
  level: number;
}

export interface Specialization {
  title: string;
  description: string;
  icon: string;
}

export interface Achievement {
  title: string;
  description: string;
  date: string;
  category: string;
}

export interface Certification {
  name: string;
  issuer: string;
  date: string;
  credentialId?: string;
  url?: string;
}

export interface MediumArticle {
  title: string;
  link: string;
  pubDate: string;
  description: string;
  thumbnail?: string;
}

// Dork Database Types
export interface Dork {
  id: string;
  query: string;
  category: string;
  description?: string;
  platform: 'github' | 'shodan' | 'google' | 'bugbounty' | 'recon';
}

export interface DorkCategory {
  name: string;
  count: number;
  platform: string;
}

// Contact Form
export const contactFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  subject: z.string().min(3, "Subject must be at least 3 characters"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

export type ContactFormData = z.infer<typeof contactFormSchema>;

// User & Auth (for future features)
export const userSchema = z.object({
  id: z.string(),
  username: z.string(),
  email: z.string().email(),
  createdAt: z.string(),
});

export const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export const loginSchema = z.object({
  username: z.string(),
  password: z.string(),
});

export type User = z.infer<typeof userSchema>;
export type RegisterData = z.infer<typeof registerSchema>;
export type LoginData = z.infer<typeof loginSchema>;

// Favorites & History (for future features)
export interface DorkFavorite {
  id: string;
  userId: string;
  dorkId: string;
  createdAt: string;
}

export interface SearchHistory {
  id: string;
  userId: string;
  query: string;
  platform: string;
  timestamp: string;
}

// Analytics (for future features)
export interface SearchAnalytics {
  id: string;
  query: string;
  platform: string;
  count: number;
  lastSearched: string;
}

// Admin Content Management (for future features)
export interface AdminContent {
  id: string;
  type: 'achievement' | 'certification' | 'bio';
  content: string;
  updatedAt: string;
}
