import { type Dork, type DorkCategory, type ContactFormData, type MediumArticle } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Dorks
  getAllDorks(platform?: string): Promise<Dork[]>;
  getDorksByCategory(platform: string, category: string): Promise<Dork[]>;
  getCategories(platform: string): Promise<DorkCategory[]>;
  
  // Contact messages (for logging/future reference)
  saveContactMessage(message: ContactFormData): Promise<void>;
  
  // Medium articles (cached)
  getMediumArticles(): Promise<MediumArticle[]>;
  cacheMediumArticles(articles: MediumArticle[]): Promise<void>;
}

export class MemStorage implements IStorage {
  private dorks: Map<string, Dork[]>;
  private mediumArticles: MediumArticle[];
  private contactMessages: ContactFormData[];

  constructor() {
    this.dorks = new Map();
    this.mediumArticles = [];
    this.contactMessages = [];
  }

  async getAllDorks(platform?: string): Promise<Dork[]> {
    if (platform) {
      return this.dorks.get(platform) || [];
    }
    return Array.from(this.dorks.values()).flat();
  }

  async getDorksByCategory(platform: string, category: string): Promise<Dork[]> {
    const platformDorks = this.dorks.get(platform) || [];
    return platformDorks.filter(d => d.category === category);
  }

  async getCategories(platform: string): Promise<DorkCategory[]> {
    const platformDorks = this.dorks.get(platform) || [];
    const categoryMap = new Map<string, number>();
    
    platformDorks.forEach(dork => {
      const count = categoryMap.get(dork.category) || 0;
      categoryMap.set(dork.category, count + 1);
    });
    
    return Array.from(categoryMap.entries())
      .map(([name, count]) => ({ name, count, platform }))
      .sort((a, b) => b.count - a.count);
  }

  async saveContactMessage(message: ContactFormData): Promise<void> {
    this.contactMessages.push(message);
  }

  async getMediumArticles(): Promise<MediumArticle[]> {
    return this.mediumArticles;
  }

  async cacheMediumArticles(articles: MediumArticle[]): Promise<void> {
    this.mediumArticles = articles;
  }

  // Helper method to initialize dorks
  initializeDorks(platform: string, dorks: Dork[]): void {
    this.dorks.set(platform, dorks);
  }
}

export const storage = new MemStorage();
