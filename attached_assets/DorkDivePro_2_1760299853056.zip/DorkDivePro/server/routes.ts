import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { contactFormSchema } from "@shared/schema";
import { parseDorkFile } from "@shared/dorkData";
import { readFileSync } from "fs";
import { join } from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize dork databases on startup
  initializeDorks();
  
  // Get all dorks or dorks for a specific platform
  app.get("/api/dorks", async (req, res) => {
    try {
      const platform = req.query.platform as string | undefined;
      const dorks = await storage.getAllDorks(platform);
      res.json(dorks);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dorks" });
    }
  });

  // Get categories for a platform
  app.get("/api/dorks/categories", async (req, res) => {
    try {
      const platform = req.query.platform as string;
      if (!platform) {
        return res.status(400).json({ error: "Platform parameter required" });
      }
      const categories = await storage.getCategories(platform);
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = contactFormSchema.parse(req.body);
      
      // Save to storage
      await storage.saveContactMessage(validatedData);
      
      // Here we would send email using SMTP when secrets are provided
      // For now, just acknowledge receipt
      
      res.json({ 
        success: true, 
        message: "Message received. Email functionality will be activated when SMTP credentials are configured." 
      });
    } catch (error: any) {
      res.status(400).json({ 
        error: "Invalid form data", 
        details: error.errors || error.message 
      });
    }
  });

  // Get Medium articles
  app.get("/api/medium", async (req, res) => {
    try {
      const articles = await storage.getMediumArticles();
      res.json(articles);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch Medium articles" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}

// Initialize dork databases from text files
function initializeDorks() {
  const dorkFiles = [
    { platform: 'github', path: 'attached_assets/github dorks all_1760212348814.txt' },
    { platform: 'shodan', path: 'attached_assets/shodan dorks all_1760212348820.txt' },
    { platform: 'google', path: 'attached_assets/google dorks all_1760212348815.txt' },
    { platform: 'bugbounty', path: 'attached_assets/Bug Bounty Dorks ALL_1760212348812.txt' },
    { platform: 'recon', path: 'attached_assets/Recon Methodology all_1760212348819.txt' },
  ];

  dorkFiles.forEach(({ platform, path }) => {
    try {
      const filePath = join(process.cwd(), path);
      const content = readFileSync(filePath, 'utf-8');
      const dorks = parseDorkFile(content, platform as any);
      storage.initializeDorks(platform, dorks);
      console.log(`✓ Loaded ${dorks.length} ${platform} dorks`);
    } catch (error) {
      console.error(`✗ Failed to load ${platform} dorks:`, error);
    }
  });

  // Initialize some sample Medium articles (will be replaced with real RSS fetch later)
  storage.cacheMediumArticles([
    {
      title: 'Advanced SQL Injection Techniques in 2024',
      link: 'https://medium.com/@sadik0x01',
      pubDate: new Date().toISOString(),
      description: 'Deep dive into modern SQL injection attack vectors and bypass techniques',
    },
    {
      title: 'IDOR Vulnerabilities: A Complete Guide',
      link: 'https://medium.com/@sadik0x01',
      pubDate: new Date().toISOString(),
      description: 'Comprehensive guide to finding and exploiting IDOR vulnerabilities',
    },
    {
      title: 'Automating Reconnaissance with Custom Tools',
      link: 'https://medium.com/@sadik0x01',
      pubDate: new Date().toISOString(),
      description: 'Building efficient automation for the reconnaissance phase',
    },
  ]);
}
