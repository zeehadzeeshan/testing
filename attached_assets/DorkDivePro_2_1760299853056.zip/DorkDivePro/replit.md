# Cybersecurity Portfolio & Dork Search Platform

## Overview

This is a professional cybersecurity portfolio website combined with an advanced dork search platform. The application showcases security research expertise while providing practical penetration testing tools including GitHub, Shodan, Google, Bug Bounty, and Recon methodology search utilities. Built with a dark cybersecurity aesthetic inspired by HackTheBox and terminal interfaces, it serves both as a personal portfolio and a functional toolset for security researchers.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and development server with hot module replacement
- **Wouter** for lightweight client-side routing
- **TanStack Query (React Query)** for server state management and data fetching

**UI Component System**
- **Shadcn/ui** component library with Radix UI primitives
- **Tailwind CSS** for utility-first styling with custom design tokens
- **Class Variance Authority (CVA)** for component variant management
- Dark-first design system with cybersecurity theme (neon green accents, terminal aesthetics)
- Custom color palette per tool section (purple for GitHub, cyan for Shodan, blue for Google, red for Bug Bounty, orange for Recon)

**Design Rationale**: Shadcn/ui was chosen for its flexibility and customizability, allowing deep theming while maintaining accessibility. The component-based approach with Radix UI ensures consistent behavior across all interactive elements.

### Backend Architecture

**Server Framework**
- **Express.js** on Node.js with ESM module support
- TypeScript for type safety across the entire stack
- Custom middleware for request logging and error handling

**API Structure**
- RESTful endpoints under `/api` prefix
- `/api/dorks` - Fetch dork queries by platform
- `/api/dorks/categories` - Get categories for filtering
- `/api/contact` - Handle contact form submissions

**Data Layer**
- **In-memory storage (MemStorage)** as the primary data store
- File-based dork database parsing from text files in `attached_assets/`
- Dork files are parsed on server startup and categorized automatically
- Contact messages stored in memory (designed for future database integration)

**Design Rationale**: The in-memory storage solution was chosen for simplicity and speed, as dork data is static and loaded at startup. This avoids database overhead for read-heavy operations. The architecture is designed to easily swap to database storage when needed.

### External Dependencies

**Database & ORM**
- **Drizzle ORM** configured with PostgreSQL dialect (schema defined, ready for integration)
- **Neon Serverless** PostgreSQL driver for serverless database connections
- Database migrations configured in `drizzle.config.ts` pointing to `./migrations`
- Schema defined in `shared/schema.ts` with Zod validation

**Note**: While Drizzle and PostgreSQL configuration exists, the current implementation uses in-memory storage. Database integration is prepared but not actively used.

**Form Handling & Validation**
- **React Hook Form** for performant form state management
- **Zod** for schema validation with TypeScript type inference
- **@hookform/resolvers** for Zod integration with React Hook Form

**UI & Styling**
- **Google Fonts**: Orbitron (display), Inter (body), Fira Code (monospace)
- **Lucide React** for consistent icon set
- **Tailwind CSS** with PostCSS and Autoprefixer

**Development Tools**
- **TSX** for running TypeScript directly in development
- **ESBuild** for production builds
- **Replit-specific plugins** for development environment integration

### Data Flow

1. **Dork Search Tools**: Client requests dorks → Server fetches from in-memory storage → Client displays with filtering/categorization
2. **Contact Form**: Client validates with Zod → Sends to `/api/contact` → Server stores in memory (prepared for email integration)
3. **Portfolio Content**: Static data rendered client-side with social links, skills, and specializations

### Security Considerations

- Input validation using Zod schemas on both client and server
- CORS and credential handling configured in API requests
- Environment variables for sensitive configuration (DATABASE_URL)
- Contact form data sanitized before storage

### File Structure

```
client/          # Frontend React application
  src/
    pages/       # Route components
    components/  # Reusable UI components
    hooks/       # Custom React hooks
    lib/         # Utilities and query client
server/          # Backend Express application
  routes.ts      # API endpoint definitions
  storage.ts     # Data layer abstraction
shared/          # Shared types and schemas
  schema.ts      # Zod schemas and TypeScript types
  dorkData.ts    # Dork parsing utilities
attached_assets/ # Static dork database files
```

### Build & Deployment

- **Development**: `npm run dev` runs TSX server with Vite dev server
- **Production**: `npm run build` creates optimized Vite build + ESBuild server bundle
- **Database**: `npm run db:push` for schema migrations (when database is connected)
- Static assets served from `dist/public` in production
- Server bundle outputs to `dist/index.js`