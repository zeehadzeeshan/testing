import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/home";
import Tools from "@/pages/tools";
import GitHubDorks from "@/pages/github-dorks";
import ShodanDorks from "@/pages/shodan-dorks";
import GoogleDorks from "@/pages/google-dorks";
import BugBountyDorks from "@/pages/bugbounty-dorks";
import ReconDorks from "@/pages/recon-dorks";
import Resume from "@/pages/resume";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/tools" component={Tools} />
      <Route path="/tools/github" component={GitHubDorks} />
      <Route path="/tools/shodan" component={ShodanDorks} />
      <Route path="/tools/google" component={GoogleDorks} />
      <Route path="/tools/bugbounty" component={BugBountyDorks} />
      <Route path="/tools/recon" component={ReconDorks} />
      <Route path="/resume" component={Resume} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
