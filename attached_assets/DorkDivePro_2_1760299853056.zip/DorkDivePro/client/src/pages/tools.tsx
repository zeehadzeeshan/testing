import { Link } from 'wouter';
import { ArrowLeft, Github, Globe, Search, Bug, Map, Network } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const dorkTools = [
  {
    name: 'GitHub Dorks',
    description: 'Search for sensitive information leaked in GitHub repositories',
    icon: Github,
    path: '/tools/github',
    color: '265 90% 65%',
    gradient: 'from-purple-600 to-purple-400',
  },
  {
    name: 'Shodan Dorks',
    description: 'Discover exposed IoT devices and services across the internet',
    icon: Network,
    path: '/tools/shodan',
    color: '190 85% 55%',
    gradient: 'from-cyan-600 to-cyan-400',
  },
  {
    name: 'Google Dorks',
    description: 'Advanced Google search queries for security research',
    icon: Globe,
    path: '/tools/google',
    color: '220 85% 60%',
    gradient: 'from-blue-600 to-blue-400',
  },
  {
    name: 'Bug Bounty Dorks',
    description: 'Find bug bounty programs and vulnerability disclosure policies',
    icon: Bug,
    path: '/tools/bugbounty',
    color: '0 75% 60%',
    gradient: 'from-red-600 to-red-400',
  },
  {
    name: 'Recon Methodology',
    description: 'Comprehensive reconnaissance workflow and tool integration',
    icon: Map,
    path: '/tools/recon',
    color: '30 85% 60%',
    gradient: 'from-orange-600 to-orange-400',
  },
];

export default function Tools() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-lg bg-background/80 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Button asChild variant="ghost" data-testid="button-back-home">
            <Link href="/">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Portfolio
            </Link>
          </Button>
          
          <div className="flex items-center gap-2">
            <Search className="w-5 h-5 text-primary" />
            <h1 className="text-xl font-display font-bold">Dork Search Tools</h1>
          </div>

          <div className="w-32"></div>
        </div>
      </header>

      {/* Hero */}
      <section className="py-24 px-4">
        <div className="max-w-7xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-3 mb-6 px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
            <span className="w-2 h-2 bg-primary rounded-full animate-pulse"></span>
            <span className="text-sm font-mono text-primary">Security Research Tools</span>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-display font-bold mb-6">
            Advanced <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Dork Search</span> Tools
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive collection of search queries (dorks) for security research, reconnaissance, 
            and bug bounty hunting. Each tool is specifically designed for different platforms and use cases.
          </p>
        </div>

        {/* Tools Grid */}
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {dorkTools.map((tool) => {
            const Icon = tool.icon;
            return (
              <Link href={tool.path} key={tool.name}>
                <Card className="p-8 h-full hover-elevate active-elevate-2 transition-all duration-300 cursor-pointer group border-l-4" style={{ borderLeftColor: `hsl(${tool.color})` } as React.CSSProperties} data-testid={`card-tool-${tool.name.toLowerCase().replace(/\s+/g, '-')}`}>
                  <div className="mb-6">
                    <div 
                      className={`inline-flex items-center justify-center w-16 h-16 rounded-lg bg-gradient-to-br ${tool.gradient} p-0.5 mb-4`}
                    >
                      <div className="w-full h-full bg-background rounded-lg flex items-center justify-center">
                        <Icon className="w-8 h-8" style={{ color: `hsl(${tool.color})` }} />
                      </div>
                    </div>
                  </div>

                  <h3 className="text-2xl font-display font-bold mb-3 group-hover:text-primary transition-colors">
                    {tool.name}
                  </h3>
                  
                  <p className="text-muted-foreground mb-4">
                    {tool.description}
                  </p>

                  <div className="flex items-center gap-2 text-sm font-medium" style={{ color: `hsl(${tool.color})` }}>
                    <span>Explore Tool</span>
                    <span className="transform group-hover:translate-x-1 transition-transform">→</span>
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Info Section */}
      <section className="py-16 px-4 bg-card/30">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="p-6 text-center">
              <div className="text-4xl font-bold text-primary mb-2">5</div>
              <p className="text-muted-foreground">Specialized Tools</p>
            </Card>

            <Card className="p-6 text-center">
              <div className="text-4xl font-bold text-primary mb-2">1000+</div>
              <p className="text-muted-foreground">Dork Queries</p>
            </Card>

            <Card className="p-6 text-center">
              <div className="text-4xl font-bold text-primary mb-2">∞</div>
              <p className="text-muted-foreground">Research Possibilities</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Disclaimer */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <Card className="p-8 bg-destructive/5 border-destructive/20">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span className="text-destructive">⚠️</span>
              Responsible Use Disclaimer
            </h3>
            <p className="text-muted-foreground">
              These tools are intended for ethical security research, authorized penetration testing, 
              and bug bounty programs only. Always obtain proper authorization before testing any systems 
              you don't own. Unauthorized access to computer systems is illegal and unethical.
            </p>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-8 px-4">
        <div className="max-w-7xl mx-auto text-center text-muted-foreground">
          <p>© {new Date().getFullYear()} Sadik. Built for ethical hackers and security researchers.</p>
        </div>
      </footer>
    </div>
  );
}
