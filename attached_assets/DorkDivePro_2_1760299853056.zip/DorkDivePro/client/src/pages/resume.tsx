import { Link } from 'wouter';
import { ArrowLeft, FileText, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

export default function Resume() {
  // This will be connected to actual resume PDF when provided
  const resumeUrl = null; // Will be set to actual PDF URL

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/50 backdrop-blur-lg bg-background/80 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Button asChild variant="ghost" data-testid="button-back">
            <Link href="/">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Portfolio
            </Link>
          </Button>
          
          <div className="flex items-center gap-3">
            <FileText className="w-6 h-6 text-primary" />
            <h1 className="text-xl font-display font-bold">Resume</h1>
          </div>

          <div className="w-32"></div>
        </div>
      </header>

      <section className="py-16 px-4">
        <div className="max-w-5xl mx-auto">
          {resumeUrl ? (
            <div className="bg-card rounded-lg overflow-hidden border border-border shadow-2xl">
              <iframe
                src={`${resumeUrl}#toolbar=0&navpanes=0&scrollbar=0`}
                className="w-full h-[800px]"
                title="Resume PDF Viewer"
                data-testid="pdf-viewer"
              />
              <div className="p-4 border-t border-border bg-card/50 text-sm text-muted-foreground text-center">
                Note: Download is disabled to protect privacy. View-only access.
              </div>
            </div>
          ) : (
            <Card className="p-16 text-center">
              <FileText className="w-24 h-24 mx-auto mb-6 text-primary/30" />
              <h2 className="text-3xl font-display font-bold mb-4">Resume Coming Soon</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                The resume viewer will be available here once the PDF is uploaded. 
                It will be displayed in view-only mode for privacy protection.
              </p>
            </Card>
          )}
        </div>
      </section>
    </div>
  );
}
