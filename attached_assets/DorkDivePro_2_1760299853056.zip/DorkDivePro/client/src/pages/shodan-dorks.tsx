import { useState, useMemo } from 'react';
import { Link } from 'wouter';
import { ArrowLeft, Search, Copy, Check, Network } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { useDorks, useDorkCategories } from '@/hooks/use-dorks';

export default function ShodanDorks() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const { data: shodanDorks = [], isLoading: isDorksLoading } = useDorks('shodan');
  const { data: categoriesData = [], isLoading: isCategoriesLoading } = useDorkCategories('shodan');

  const categories = useMemo(() => {
    return categoriesData.map(c => c.name);
  }, [categoriesData]);

  const filteredDorks = useMemo(() => {
    return shodanDorks.filter(dork => {
      const matchesSearch = dork.query.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = !selectedCategory || dork.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [shodanDorks, searchQuery, selectedCategory]);

  const copyDork = async (dork: string, id: string) => {
    await navigator.clipboard.writeText(dork);
    setCopiedId(id);
    toast({
      title: 'Copied!',
      description: 'Dork query copied to clipboard',
    });
    setTimeout(() => setCopiedId(null), 2000);
  };

  const executeSearch = (query: string) => {
    window.open(`https://www.shodan.io/search?query=${encodeURIComponent(query)}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-cyan-500/30 backdrop-blur-lg bg-background/80 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Button asChild variant="ghost" data-testid="button-back">
            <Link href="/tools">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Tools
            </Link>
          </Button>
          
          <div className="flex items-center gap-3">
            <Network className="w-6 h-6 text-cyan-500" />
            <h1 className="text-xl font-display font-bold">Shodan Dorks</h1>
          </div>

          <div className="w-32"></div>
        </div>
      </header>

      <section className="py-16 px-4 bg-gradient-to-b from-cyan-950/20 to-background">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-500/10 border border-cyan-500/20 mb-6">
              <Network className="w-4 h-4 text-cyan-400" />
              <span className="text-sm font-mono text-cyan-400">IoT & Network Discovery</span>
            </div>
            
            <h1 className="text-4xl md:text-5xl font-display font-bold mb-4 text-cyan-400">
              Shodan Search Dorks
            </h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Discover exposed IoT devices, servers, and services across the internet using powerful Shodan queries
            </p>
          </div>

          <div className="max-w-3xl mx-auto mb-8">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input
                type="search"
                placeholder="Search dorks..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-14 text-lg bg-card border-cyan-500/30 focus:border-cyan-500"
                data-testid="input-search"
              />
            </div>
          </div>

          <div className="flex gap-3 justify-center flex-wrap mb-8">
            <Badge
              variant={selectedCategory === null ? 'default' : 'outline'}
              className="cursor-pointer px-4 py-2"
              onClick={() => setSelectedCategory(null)}
              data-testid="filter-all"
            >
              All
            </Badge>
            {categories.map(cat => (
              <Badge
                key={cat}
                variant={selectedCategory === cat ? 'default' : 'outline'}
                className="cursor-pointer px-4 py-2"
                onClick={() => setSelectedCategory(cat)}
                data-testid={`filter-${cat.toLowerCase().replace(/\s+/g, '-')}`}
              >
                {cat}
              </Badge>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          {isDorksLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="p-6">
                  <Skeleton className="h-6 w-20 mb-3" />
                  <Skeleton className="h-20 w-full mb-4" />
                  <Skeleton className="h-10 w-full" />
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredDorks.map(dork => (
              <Card key={dork.id} className="p-6 hover-elevate transition-all border-l-4 border-l-cyan-500" data-testid={`card-dork-${dork.id}`}>
                <div className="flex items-start justify-between mb-3">
                  <Badge variant="secondary" className="text-xs">{dork.category}</Badge>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => copyDork(dork.query, dork.id)}
                    className="h-8 w-8"
                    data-testid={`button-copy-${dork.id}`}
                  >
                    {copiedId === dork.id ? (
                      <Check className="w-4 h-4 text-green-500" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </Button>
                </div>

                <code className="block p-3 bg-secondary/50 rounded text-sm font-mono mb-4 text-cyan-300 break-all">
                  {dork.query}
                </code>

                <Button
                  onClick={() => executeSearch(dork.query)}
                  className="w-full bg-cyan-600 hover:bg-cyan-700"
                  data-testid={`button-search-${dork.id}`}
                >
                  <Search className="w-4 h-4 mr-2" />
                  Search on Shodan
                </Button>
              </Card>
              ))}
            </div>
          )}

          {!isDorksLoading && filteredDorks.length === 0 && (
            <div className="text-center py-16">
              <p className="text-muted-foreground text-lg">No dorks found matching your search</p>
            </div>
          )}
        </div>
      </section>

      <footer className="border-t border-border/50 py-8 px-4 mt-16">
        <div className="max-w-7xl mx-auto text-center text-muted-foreground">
          <p className="text-sm">🔍 Shodan Dorks - Responsible IoT security research only</p>
        </div>
      </footer>
    </div>
  );
}
