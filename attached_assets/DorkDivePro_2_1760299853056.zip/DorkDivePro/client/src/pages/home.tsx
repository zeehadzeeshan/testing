import { useState } from 'react';
import { Link } from 'wouter';
import { Github, Linkedin, Twitter, Facebook, MessageCircle, Award, Mail, Send, Shield, Pen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { contactFormSchema, type ContactFormData } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import profilePhoto from '@assets/My Profile Photo_1760212348818.jpg';

const socialLinks = [
  { platform: 'Twitter', url: 'https://x.com/sadik0x01', icon: Twitter, color: '#1DA1F2' },
  { platform: 'LinkedIn', url: 'https://linkedin.com/in/sadik0x01', icon: Linkedin, color: '#0A66C2' },
  { platform: 'Facebook', url: 'https://facebook.com/sadik0x01', icon: Facebook, color: '#1877F2' },
  { platform: 'GitHub', url: 'https://github.com/sadik0x01', icon: Github, color: '#ffffff' },
  { platform: 'Discord', url: 'https://discord.com/users/sadik0x01', icon: MessageCircle, color: '#5865F2' },
  { platform: 'HackTheBox', url: 'https://app.hackthebox.com/profile/sadik0x01', icon: Shield, color: '#9FEF00' },
  { platform: 'Medium', url: 'https://medium.com/@sadik0x01', icon: Pen, color: '#00AB6C' },
];

const skills = [
  { name: 'Penetration Testing', level: 95 },
  { name: 'Web Application Security', level: 90 },
  { name: 'Network Security', level: 88 },
  { name: 'Vulnerability Assessment', level: 92 },
  { name: 'Bug Bounty Hunting', level: 87 },
  { name: 'OSINT & Recon', level: 93 },
];

const specializations = [
  {
    title: 'Web Security',
    description: 'Expert in identifying and exploiting web application vulnerabilities',
    icon: '🌐'
  },
  {
    title: 'API Testing',
    description: 'Comprehensive API security assessment and penetration testing',
    icon: '🔌'
  },
  {
    title: 'Cloud Security',
    description: 'Securing cloud infrastructure and containerized applications',
    icon: '☁️'
  },
];

const mediumArticles = [
  {
    title: 'Advanced SQL Injection Techniques in 2024',
    link: 'https://medium.com/@sadik0x01',
    pubDate: 'Recent',
    description: 'Deep dive into modern SQL injection attack vectors and bypass techniques',
  },
  {
    title: 'IDOR Vulnerabilities: A Complete Guide',
    link: 'https://medium.com/@sadik0x01',
    pubDate: 'Recent',
    description: 'Comprehensive guide to finding and exploiting IDOR vulnerabilities',
  },
  {
    title: 'Automating Reconnaissance with Custom Tools',
    link: 'https://medium.com/@sadik0x01',
    pubDate: 'Recent',
    description: 'Building efficient automation for the reconnaissance phase',
  },
];

export default function Home() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: '',
      email: '',
      subject: '',
      message: '',
    },
  });

  async function onSubmit(data: ContactFormData) {
    setIsSubmitting(true);
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error('Failed to send message');
      }

      const result = await response.json();
      
      toast({
        title: 'Message Sent!',
        description: result.message || 'Thank you for reaching out. I\'ll get back to you soon.',
      });
      form.reset();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to send message. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background"></div>
        
        <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
          {/* Animated Profile Picture */}
          <div className="mb-8 flex justify-center">
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-primary via-accent to-primary rounded-full opacity-75 group-hover:opacity-100 blur animate-pulse"></div>
              <div className="relative w-64 h-64 rounded-full overflow-hidden border-4 border-primary/50 transition-transform duration-300 group-hover:scale-105">
                <img 
                  src={profilePhoto} 
                  alt="Sadik - Cybersecurity Researcher" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>

          {/* Terminal-style greeting */}
          <div className="mb-6 font-mono text-primary text-lg">
            <span className="animate-pulse">{'> '}</span>
            <span className="text-muted-foreground">sadik@security:~$ whoami</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-display font-bold mb-6 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
            SADIK
          </h1>
          
          <p className="text-2xl md:text-3xl text-muted-foreground mb-8 font-medium">
            Cybersecurity Researcher & Penetration Tester
          </p>

          <div className="flex gap-4 justify-center mb-12">
            <Button asChild size="lg" data-testid="button-contact">
              <a href="#contact">Contact Me</a>
            </Button>
            <Button asChild variant="outline" size="lg" data-testid="button-tools">
              <Link href="/tools">Dork Tools</Link>
            </Button>
          </div>

          {/* Social Links */}
          <div className="flex gap-4 justify-center">
            {socialLinks.map((social) => {
              const Icon = social.icon;
              return (
                <a
                  key={social.platform}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 rounded-full border border-border hover-elevate active-elevate-2 transition-all duration-300"
                  style={{ '--hover-color': social.color } as React.CSSProperties}
                  data-testid={`link-${social.platform.toLowerCase()}`}
                >
                  <Icon className="w-5 h-5" />
                </a>
              );
            })}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-12 text-center">
            <span className="text-primary font-mono">{'> '}</span>About Me
          </h2>
          
          <div className="grid md:grid-cols-2 gap-12 mb-16">
            <div className="space-y-6">
              <Card className="p-8 border-l-4 border-l-primary">
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Passionate cybersecurity professional specializing in penetration testing, vulnerability assessment, 
                  and security research. With extensive experience in bug bounty programs and responsible disclosure, 
                  I help organizations identify and remediate security vulnerabilities before they can be exploited.
                </p>
              </Card>
              
              <Card className="p-8 border-l-4 border-l-accent">
                <p className="text-lg text-muted-foreground leading-relaxed">
                  My expertise spans web application security, network penetration testing, and advanced reconnaissance 
                  techniques. I'm committed to continuous learning and sharing knowledge with the security community.
                </p>
              </Card>
            </div>

            <div className="space-y-4">
              <h3 className="text-2xl font-display font-bold mb-6">Skills</h3>
              {skills.map((skill) => (
                <div key={skill.name} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">{skill.name}</span>
                    <span className="text-primary font-mono">{skill.level}%</span>
                  </div>
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-1000"
                      style={{ width: `${skill.level}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Specialization Section */}
      <section id="specialization" className="py-24 px-4 bg-card/30">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-12 text-center">
            <span className="text-primary font-mono">{'> '}</span>Specializations
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {specializations.map((spec) => (
              <Card key={spec.title} className="p-8 hover-elevate transition-all duration-300 border-l-4 border-l-primary">
                <div className="text-5xl mb-4">{spec.icon}</div>
                <h3 className="text-xl font-display font-bold mb-3">{spec.title}</h3>
                <p className="text-muted-foreground">{spec.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements Section - Placeholder */}
      <section id="achievements" className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-12 text-center">
            <span className="text-primary font-mono">{'> '}</span>Achievements
          </h2>
          
          <Card className="p-12 text-center border-dashed border-2">
            <Award className="w-16 h-16 mx-auto mb-4 text-primary/50" />
            <p className="text-xl text-muted-foreground">Timeline of achievements coming soon...</p>
          </Card>
        </div>
      </section>

      {/* Certifications Section */}
      <section id="certifications" className="py-24 px-4 bg-card/30">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-12 text-center">
            <span className="text-primary font-mono">{'> '}</span>Certifications
          </h2>
          
          <Card className="p-16 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent"></div>
            <div className="relative z-10">
              <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-primary/10 mb-6">
                <Award className="w-12 h-12 text-primary" />
              </div>
              <h3 className="text-3xl font-display font-bold mb-4">Coming Soon</h3>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Professional certifications and credentials will be displayed here. 
                Stay tuned for updates on OSCP, CEH, and other security certifications.
              </p>
            </div>
          </Card>
        </div>
      </section>

      {/* Writeups Section */}
      <section id="writeups" className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-12 text-center">
            <span className="text-primary font-mono">{'> '}</span>Latest Writeups
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {mediumArticles.map((article) => (
              <Card key={article.title} className="p-6 hover-elevate transition-all duration-300">
                <Badge className="mb-4">{article.pubDate}</Badge>
                <h3 className="text-xl font-bold mb-3">{article.title}</h3>
                <p className="text-muted-foreground mb-4">{article.description}</p>
                <a 
                  href={article.link} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline inline-flex items-center gap-2"
                  data-testid={`link-article-${article.title.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  Read Article →
                </a>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <Button asChild variant="outline" size="lg" data-testid="button-read-articles">
              <a href="https://medium.com/@sadik0x01" target="_blank" rel="noopener noreferrer">
                Read All Articles
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 px-4 bg-card/30">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-12 text-center">
            <span className="text-primary font-mono">{'> '}</span>Get In Touch
          </h2>
          
          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="p-8">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            placeholder="Your name" 
                            className="bg-background" 
                            data-testid="input-name"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="email" 
                            placeholder="your@email.com" 
                            className="bg-background"
                            data-testid="input-email"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="subject"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Subject</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            placeholder="What's this about?" 
                            className="bg-background"
                            data-testid="input-subject"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Message</FormLabel>
                        <FormControl>
                          <Textarea 
                            {...field} 
                            placeholder="Your message..." 
                            rows={5}
                            className="bg-background resize-none"
                            data-testid="input-message"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={isSubmitting}
                    data-testid="button-submit-contact"
                  >
                    {isSubmitting ? (
                      'Sending...'
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Send Message
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </Card>

            {/* Contact Info */}
            <div className="space-y-6">
              <Card className="p-6">
                <div className="flex items-start gap-4">
                  <Mail className="w-6 h-6 text-primary mt-1" />
                  <div>
                    <h3 className="font-bold mb-1">Email</h3>
                    <a 
                      href="mailto:sadikm0x01@gmail.com" 
                      className="text-muted-foreground hover:text-primary transition-colors"
                      data-testid="link-email"
                    >
                      sadikm0x01@gmail.com
                    </a>
                  </div>
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="font-bold mb-4">Connect</h3>
                <div className="flex flex-wrap gap-3">
                  {socialLinks.map((social) => {
                    const Icon = social.icon;
                    return (
                      <a
                        key={social.platform}
                        href={social.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-3 rounded-lg border border-border hover-elevate active-elevate-2 transition-all"
                        data-testid={`link-footer-${social.platform.toLowerCase()}`}
                      >
                        <Icon className="w-5 h-5" />
                      </a>
                    );
                  })}
                </div>
              </Card>

              <Card className="p-6 bg-primary/5 border-primary/20">
                <p className="text-sm text-muted-foreground">
                  💡 <strong>Looking for collaboration?</strong> I'm always interested in working on 
                  challenging security projects and research opportunities. Feel free to reach out!
                </p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-12 mb-8">
            <div>
              <h3 className="font-display font-bold text-xl mb-4">About</h3>
              <p className="text-muted-foreground">
                Cybersecurity researcher dedicated to making the digital world safer through 
                ethical hacking and responsible disclosure.
              </p>
            </div>

            <div>
              <h3 className="font-display font-bold text-xl mb-4">Quick Links</h3>
              <div className="space-y-2">
                <Link href="/tools" className="block text-muted-foreground hover:text-primary transition-colors" data-testid="link-footer-tools">
                  Dork Search Tools
                </Link>
                <a href="#about" className="block text-muted-foreground hover:text-primary transition-colors">
                  About
                </a>
                <a href="#contact" className="block text-muted-foreground hover:text-primary transition-colors">
                  Contact
                </a>
              </div>
            </div>

            <div>
              <h3 className="font-display font-bold text-xl mb-4">Connect</h3>
              <div className="flex gap-3 flex-wrap">
                {socialLinks.slice(0, 4).map((social) => {
                  const Icon = social.icon;
                  return (
                    <a
                      key={social.platform}
                      href={social.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded border border-border hover-elevate transition-all"
                    >
                      <Icon className="w-4 h-4" />
                    </a>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-primary/20">
            <p className="text-center text-muted-foreground">
              © {new Date().getFullYear()} Sadik. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
