import { useQuery } from '@tanstack/react-query';
import type { Dork, DorkCategory } from '@shared/schema';

export function useDorks(platform: string) {
  return useQuery<Dork[]>({
    queryKey: ['/api/dorks', platform],
    queryFn: async () => {
      const response = await fetch(`/api/dorks?platform=${platform}`);
      if (!response.ok) throw new Error('Failed to fetch dorks');
      return response.json();
    },
  });
}

export function useDorkCategories(platform: string) {
  return useQuery<DorkCategory[]>({
    queryKey: ['/api/dorks/categories', platform],
    queryFn: async () => {
      const response = await fetch(`/api/dorks/categories?platform=${platform}`);
      if (!response.ok) throw new Error('Failed to fetch categories');
      return response.json();
    },
  });
}
